"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = createISMCluster;

var _ismPlugin = _interopRequireDefault(require("./ismPlugin"));

var _constants = require("../../utils/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
function createISMCluster(server) {
  const {
    customHeaders,
    ...rest
  } = server.config().get("elasticsearch");
  server.plugins.elasticsearch.createCluster(_constants.CLUSTER.ISM, {
    plugins: [_ismPlugin.default],
    customHeaders: { ...customHeaders,
      ..._constants.DEFAULT_HEADERS
    },
    ...rest
  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZUlTTUNsdXN0ZXIudHMiXSwibmFtZXMiOlsiY3JlYXRlSVNNQ2x1c3RlciIsInNlcnZlciIsImN1c3RvbUhlYWRlcnMiLCJyZXN0IiwiY29uZmlnIiwiZ2V0IiwicGx1Z2lucyIsImVsYXN0aWNzZWFyY2giLCJjcmVhdGVDbHVzdGVyIiwiQ0xVU1RFUiIsIklTTSIsImlzbVBsdWdpbiIsIkRFRkFVTFRfSEVBREVSUyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWdCQTs7QUFDQTs7OztBQWpCQTs7Ozs7Ozs7Ozs7Ozs7QUFxQmUsU0FBU0EsZ0JBQVQsQ0FBMEJDLE1BQTFCLEVBQTBDO0FBQ3ZELFFBQU07QUFBRUMsSUFBQUEsYUFBRjtBQUFpQixPQUFHQztBQUFwQixNQUE2QkYsTUFBTSxDQUFDRyxNQUFQLEdBQWdCQyxHQUFoQixDQUFvQixlQUFwQixDQUFuQztBQUNBSixFQUFBQSxNQUFNLENBQUNLLE9BQVAsQ0FBZUMsYUFBZixDQUE2QkMsYUFBN0IsQ0FBMkNDLG1CQUFRQyxHQUFuRCxFQUF3RDtBQUN0REosSUFBQUEsT0FBTyxFQUFFLENBQUNLLGtCQUFELENBRDZDO0FBRXREVCxJQUFBQSxhQUFhLEVBQUUsRUFBRSxHQUFHQSxhQUFMO0FBQW9CLFNBQUdVO0FBQXZCLEtBRnVDO0FBR3RELE9BQUdUO0FBSG1ELEdBQXhEO0FBS0QiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IDIwMTkgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxuICogZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBMZWdhY3kgfSBmcm9tIFwia2liYW5hXCI7XG5pbXBvcnQgaXNtUGx1Z2luIGZyb20gXCIuL2lzbVBsdWdpblwiO1xuaW1wb3J0IHsgQ0xVU1RFUiwgREVGQVVMVF9IRUFERVJTIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2NvbnN0YW50c1wiO1xuXG50eXBlIFNlcnZlciA9IExlZ2FjeS5TZXJ2ZXI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZUlTTUNsdXN0ZXIoc2VydmVyOiBTZXJ2ZXIpIHtcbiAgY29uc3QgeyBjdXN0b21IZWFkZXJzLCAuLi5yZXN0IH0gPSBzZXJ2ZXIuY29uZmlnKCkuZ2V0KFwiZWxhc3RpY3NlYXJjaFwiKTtcbiAgc2VydmVyLnBsdWdpbnMuZWxhc3RpY3NlYXJjaC5jcmVhdGVDbHVzdGVyKENMVVNURVIuSVNNLCB7XG4gICAgcGx1Z2luczogW2lzbVBsdWdpbl0sXG4gICAgY3VzdG9tSGVhZGVyczogeyAuLi5jdXN0b21IZWFkZXJzLCAuLi5ERUZBVUxUX0hFQURFUlMgfSxcbiAgICAuLi5yZXN0LFxuICB9KTtcbn1cbiJdfQ==