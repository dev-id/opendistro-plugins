"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
const coreServicesMock = {
  uiSettings: {
    get: jest.fn()
  },
  chrome: {
    setBreadcrumbs: jest.fn()
  },
  notifications: {
    toasts: {
      addDanger: jest.fn().mockName("addDanger"),
      addSuccess: jest.fn().mockName("addSuccess")
    }
  }
};
var _default = coreServicesMock;
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvcmVTZXJ2aWNlc01vY2sudHMiXSwibmFtZXMiOlsiY29yZVNlcnZpY2VzTW9jayIsInVpU2V0dGluZ3MiLCJnZXQiLCJqZXN0IiwiZm4iLCJjaHJvbWUiLCJzZXRCcmVhZGNydW1icyIsIm5vdGlmaWNhdGlvbnMiLCJ0b2FzdHMiLCJhZGREYW5nZXIiLCJtb2NrTmFtZSIsImFkZFN1Y2Nlc3MiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsTUFBTUEsZ0JBQWdCLEdBQUc7QUFDdkJDLEVBQUFBLFVBQVUsRUFBRTtBQUNWQyxJQUFBQSxHQUFHLEVBQUVDLElBQUksQ0FBQ0MsRUFBTDtBQURLLEdBRFc7QUFJdkJDLEVBQUFBLE1BQU0sRUFBRTtBQUNOQyxJQUFBQSxjQUFjLEVBQUVILElBQUksQ0FBQ0MsRUFBTDtBQURWLEdBSmU7QUFPdkJHLEVBQUFBLGFBQWEsRUFBRTtBQUNiQyxJQUFBQSxNQUFNLEVBQUU7QUFDTkMsTUFBQUEsU0FBUyxFQUFFTixJQUFJLENBQUNDLEVBQUwsR0FBVU0sUUFBVixDQUFtQixXQUFuQixDQURMO0FBRU5DLE1BQUFBLFVBQVUsRUFBRVIsSUFBSSxDQUFDQyxFQUFMLEdBQVVNLFFBQVYsQ0FBbUIsWUFBbkI7QUFGTjtBQURLO0FBUFEsQ0FBekI7ZUFlZVYsZ0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IDIwMjAgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLlxuICogWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBvciBpbiB0aGUgXCJsaWNlbnNlXCIgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWRcbiAqIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxuICogZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBDb3JlU3RhcnQgfSBmcm9tIFwia2liYW5hL3B1YmxpY1wiO1xuXG5jb25zdCBjb3JlU2VydmljZXNNb2NrID0ge1xuICB1aVNldHRpbmdzOiB7XG4gICAgZ2V0OiBqZXN0LmZuKCksXG4gIH0sXG4gIGNocm9tZToge1xuICAgIHNldEJyZWFkY3J1bWJzOiBqZXN0LmZuKCksXG4gIH0sXG4gIG5vdGlmaWNhdGlvbnM6IHtcbiAgICB0b2FzdHM6IHtcbiAgICAgIGFkZERhbmdlcjogamVzdC5mbigpLm1vY2tOYW1lKFwiYWRkRGFuZ2VyXCIpLFxuICAgICAgYWRkU3VjY2VzczogamVzdC5mbigpLm1vY2tOYW1lKFwiYWRkU3VjY2Vzc1wiKSxcbiAgICB9LFxuICB9LFxufTtcblxuZXhwb3J0IGRlZmF1bHQgY29yZVNlcnZpY2VzTW9jayBhcyBDb3JlU3RhcnQ7XG4iXX0=