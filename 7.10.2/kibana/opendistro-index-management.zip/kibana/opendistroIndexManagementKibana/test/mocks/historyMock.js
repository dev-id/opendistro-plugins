"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
const historyMock = {
  action: "REPLACE",
  // PUSH, REPLACE, POP
  block: jest.fn(),
  // prevents navigation
  createHref: jest.fn(),
  go: jest.fn(),
  // moves the pointer in the history stack by n entries
  goBack: jest.fn(),
  // equivalent to go(-1)
  goForward: jest.fn(),
  // equivalent to go(1)
  length: 0,
  // number of entries in the history stack
  listen: jest.fn(),
  location: {
    hash: "",
    // URL hash fragment
    pathname: "",
    // path of URL
    search: "",
    // URL query string
    state: undefined // location-specific state that was provided to e.g. push(path, state) when this location was pushed onto the stack

  },
  push: jest.fn(),
  // pushes new entry onto history stack
  replace: jest.fn() // replaces current entry on history stack

};
var _default = historyMock;
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpc3RvcnlNb2NrLnRzIl0sIm5hbWVzIjpbImhpc3RvcnlNb2NrIiwiYWN0aW9uIiwiYmxvY2siLCJqZXN0IiwiZm4iLCJjcmVhdGVIcmVmIiwiZ28iLCJnb0JhY2siLCJnb0ZvcndhcmQiLCJsZW5ndGgiLCJsaXN0ZW4iLCJsb2NhdGlvbiIsImhhc2giLCJwYXRobmFtZSIsInNlYXJjaCIsInN0YXRlIiwidW5kZWZpbmVkIiwicHVzaCIsInJlcGxhY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7QUFlQSxNQUFNQSxXQUFXLEdBQUc7QUFDbEJDLEVBQUFBLE1BQU0sRUFBRSxTQURVO0FBQ0M7QUFDbkJDLEVBQUFBLEtBQUssRUFBRUMsSUFBSSxDQUFDQyxFQUFMLEVBRlc7QUFFQTtBQUNsQkMsRUFBQUEsVUFBVSxFQUFFRixJQUFJLENBQUNDLEVBQUwsRUFITTtBQUlsQkUsRUFBQUEsRUFBRSxFQUFFSCxJQUFJLENBQUNDLEVBQUwsRUFKYztBQUlIO0FBQ2ZHLEVBQUFBLE1BQU0sRUFBRUosSUFBSSxDQUFDQyxFQUFMLEVBTFU7QUFLQztBQUNuQkksRUFBQUEsU0FBUyxFQUFFTCxJQUFJLENBQUNDLEVBQUwsRUFOTztBQU1JO0FBQ3RCSyxFQUFBQSxNQUFNLEVBQUUsQ0FQVTtBQU9QO0FBQ1hDLEVBQUFBLE1BQU0sRUFBRVAsSUFBSSxDQUFDQyxFQUFMLEVBUlU7QUFTbEJPLEVBQUFBLFFBQVEsRUFBRTtBQUNSQyxJQUFBQSxJQUFJLEVBQUUsRUFERTtBQUNFO0FBQ1ZDLElBQUFBLFFBQVEsRUFBRSxFQUZGO0FBRU07QUFDZEMsSUFBQUEsTUFBTSxFQUFFLEVBSEE7QUFHSTtBQUNaQyxJQUFBQSxLQUFLLEVBQUVDLFNBSkMsQ0FJVTs7QUFKVixHQVRRO0FBZWxCQyxFQUFBQSxJQUFJLEVBQUVkLElBQUksQ0FBQ0MsRUFBTCxFQWZZO0FBZUQ7QUFDakJjLEVBQUFBLE9BQU8sRUFBRWYsSUFBSSxDQUFDQyxFQUFMLEVBaEJTLENBZ0JFOztBQWhCRixDQUFwQjtlQW1CZUosVyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgMjAxOSBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xuICogcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmNvbnN0IGhpc3RvcnlNb2NrID0ge1xuICBhY3Rpb246IFwiUkVQTEFDRVwiLCAvLyBQVVNILCBSRVBMQUNFLCBQT1BcbiAgYmxvY2s6IGplc3QuZm4oKSwgLy8gcHJldmVudHMgbmF2aWdhdGlvblxuICBjcmVhdGVIcmVmOiBqZXN0LmZuKCksXG4gIGdvOiBqZXN0LmZuKCksIC8vIG1vdmVzIHRoZSBwb2ludGVyIGluIHRoZSBoaXN0b3J5IHN0YWNrIGJ5IG4gZW50cmllc1xuICBnb0JhY2s6IGplc3QuZm4oKSwgLy8gZXF1aXZhbGVudCB0byBnbygtMSlcbiAgZ29Gb3J3YXJkOiBqZXN0LmZuKCksIC8vIGVxdWl2YWxlbnQgdG8gZ28oMSlcbiAgbGVuZ3RoOiAwLCAvLyBudW1iZXIgb2YgZW50cmllcyBpbiB0aGUgaGlzdG9yeSBzdGFja1xuICBsaXN0ZW46IGplc3QuZm4oKSxcbiAgbG9jYXRpb246IHtcbiAgICBoYXNoOiBcIlwiLCAvLyBVUkwgaGFzaCBmcmFnbWVudFxuICAgIHBhdGhuYW1lOiBcIlwiLCAvLyBwYXRoIG9mIFVSTFxuICAgIHNlYXJjaDogXCJcIiwgLy8gVVJMIHF1ZXJ5IHN0cmluZ1xuICAgIHN0YXRlOiB1bmRlZmluZWQsIC8vIGxvY2F0aW9uLXNwZWNpZmljIHN0YXRlIHRoYXQgd2FzIHByb3ZpZGVkIHRvIGUuZy4gcHVzaChwYXRoLCBzdGF0ZSkgd2hlbiB0aGlzIGxvY2F0aW9uIHdhcyBwdXNoZWQgb250byB0aGUgc3RhY2tcbiAgfSxcbiAgcHVzaDogamVzdC5mbigpLCAvLyBwdXNoZXMgbmV3IGVudHJ5IG9udG8gaGlzdG9yeSBzdGFja1xuICByZXBsYWNlOiBqZXN0LmZuKCksIC8vIHJlcGxhY2VzIGN1cnJlbnQgZW50cnkgb24gaGlzdG9yeSBzdGFja1xufTtcblxuZXhwb3J0IGRlZmF1bHQgaGlzdG9yeU1vY2s7XG4iXX0=