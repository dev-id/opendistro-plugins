const chrome = {
  getUiSettingsClient: () => ({ get: () => false }),
};
module.exports = chrome;
