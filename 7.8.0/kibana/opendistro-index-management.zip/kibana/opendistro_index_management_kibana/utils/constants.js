"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.REQUEST = exports.NODE_API = exports.BASE_API_PATH = void 0;

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var BASE_API_PATH = "/api/ism";
exports.BASE_API_PATH = BASE_API_PATH;
var NODE_API = Object.freeze({
  _SEARCH: "".concat(BASE_API_PATH, "/_search"),
  _INDICES: "".concat(BASE_API_PATH, "/_indices"),
  APPLY_POLICY: "".concat(BASE_API_PATH, "/applyPolicy"),
  EDIT_ROLLOVER_ALIAS: "".concat(BASE_API_PATH, "/editRolloverAlias"),
  POLICIES: "".concat(BASE_API_PATH, "/policies"),
  MANAGED_INDICES: "".concat(BASE_API_PATH, "/managedIndices"),
  RETRY: "".concat(BASE_API_PATH, "/retry"),
  CHANGE_POLICY: "".concat(BASE_API_PATH, "/changePolicy"),
  REMOVE_POLICY: "".concat(BASE_API_PATH, "/removePolicy")
});
exports.NODE_API = NODE_API;
var REQUEST = Object.freeze({
  PUT: "PUT",
  DELETE: "DELETE",
  GET: "GET",
  POST: "POST",
  HEAD: "HEAD"
});
exports.REQUEST = REQUEST;