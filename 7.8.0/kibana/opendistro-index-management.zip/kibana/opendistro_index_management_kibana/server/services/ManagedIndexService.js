"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../utils/constants");

var _helpers = require("../utils/helpers");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var ManagedIndexService = function ManagedIndexService(esDriver) {
  var _this = this;

  (0, _classCallCheck2.default)(this, ManagedIndexService);
  (0, _defineProperty2.default)(this, "esDriver", void 0);
  (0, _defineProperty2.default)(this, "getManagedIndex", /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(req, h) {
      var id, params, _this$esDriver$getClu, callWithRequest, results;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              id = req.params.id;
              params = {
                id: id,
                index: _constants.INDEX.OPENDISTRO_ISM_CONFIG
              };
              _this$esDriver$getClu = _this.esDriver.getCluster(_constants.CLUSTER.DATA), callWithRequest = _this$esDriver$getClu.callWithRequest;
              _context.next = 6;
              return callWithRequest(req, "search", params);

            case 6:
              results = _context.sent;
              return _context.abrupt("return", {
                ok: true,
                response: results
              });

            case 10:
              _context.prev = 10;
              _context.t0 = _context["catch"](0);
              console.error("Index Management - ManagedIndexService - getManagedIndex:", _context.t0);
              return _context.abrupt("return", {
                ok: false,
                error: _context.t0.message
              });

            case 14:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 10]]);
    }));

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "getManagedIndices", /*#__PURE__*/function () {
    var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(req, h) {
      var _ref3, from, size, search, sortDirection, sortField, managedIndexSorts, searchParams, _yield$_this$esDriver, callWithRequest, searchResponse, indices, totalManagedIndices, explainParams, _yield$_this$esDriver2, ismCallWithRequest, explainResponse, managedIndices;

      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _ref3 = req.query, from = _ref3.from, size = _ref3.size, search = _ref3.search, sortDirection = _ref3.sortDirection, sortField = _ref3.sortField;
              managedIndexSorts = {
                index: "managed_index.index",
                policyId: "managed_index.policy_id"
              };
              searchParams = {
                index: _constants.INDEX.OPENDISTRO_ISM_CONFIG,
                seq_no_primary_term: true,
                body: {
                  size: size,
                  from: from,
                  sort: managedIndexSorts[sortField] ? [(0, _defineProperty2.default)({}, managedIndexSorts[sortField], sortDirection)] : [],
                  query: {
                    bool: {
                      filter: [{
                        exists: {
                          field: "managed_index"
                        }
                      }],
                      must: (0, _helpers.getMustQuery)("managed_index.name", search)
                    }
                  }
                }
              };
              _context2.next = 6;
              return _this.esDriver.getCluster(_constants.CLUSTER.DATA);

            case 6:
              _yield$_this$esDriver = _context2.sent;
              callWithRequest = _yield$_this$esDriver.callWithRequest;
              _context2.next = 10;
              return callWithRequest(req, "search", searchParams);

            case 10:
              searchResponse = _context2.sent;
              indices = searchResponse.hits.hits.map(function (hit) {
                return hit._source.managed_index.index;
              });
              totalManagedIndices = _lodash.default.get(searchResponse, "hits.total.value", 0);

              if (indices.length) {
                _context2.next = 15;
                break;
              }

              return _context2.abrupt("return", {
                ok: true,
                response: {
                  managedIndices: [],
                  totalManagedIndices: 0
                }
              });

            case 15:
              explainParams = {
                index: indices.join(",")
              };
              _context2.next = 18;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 18:
              _yield$_this$esDriver2 = _context2.sent;
              ismCallWithRequest = _yield$_this$esDriver2.callWithRequest;
              _context2.next = 22;
              return ismCallWithRequest(req, "ism.explain", explainParams);

            case 22:
              explainResponse = _context2.sent;
              managedIndices = searchResponse.hits.hits.map(function (hit) {
                var index = hit._source.managed_index.index;
                return {
                  index: index,
                  indexUuid: hit._source.managed_index.index_uuid,
                  policyId: hit._source.managed_index.policy_id,
                  policySeqNo: hit._source.managed_index.policy_seq_no,
                  policyPrimaryTerm: hit._source.managed_index.policy_primary_term,
                  policy: hit._source.managed_index.policy,
                  enabled: hit._source.managed_index.enabled,
                  managedIndexMetaData: (0, _helpers.transformManagedIndexMetaData)(explainResponse[index]) // this will be undefined if we are initializing

                };
              });
              return _context2.abrupt("return", {
                ok: true,
                response: {
                  managedIndices: managedIndices,
                  totalManagedIndices: totalManagedIndices
                }
              });

            case 27:
              _context2.prev = 27;
              _context2.t0 = _context2["catch"](0);

              if (!(_context2.t0.statusCode === 404 && _context2.t0.body.error.type === "index_not_found_exception")) {
                _context2.next = 31;
                break;
              }

              return _context2.abrupt("return", {
                ok: true,
                response: {
                  managedIndices: [],
                  totalManagedIndices: 0
                }
              });

            case 31:
              console.error("Index Management - ManagedIndexService - getManagedIndices", _context2.t0);
              return _context2.abrupt("return", {
                ok: false,
                error: _context2.t0.message
              });

            case 33:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 27]]);
    }));

    return function (_x3, _x4) {
      return _ref2.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "retryManagedIndexPolicy", /*#__PURE__*/function () {
    var _ref5 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(req, h) {
      var _ref6, index, _ref6$state, state, _yield$_this$esDriver3, callWithRequest, params, retryResponse;

      return _regenerator.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              _ref6 = req.payload, index = _ref6.index, _ref6$state = _ref6.state, state = _ref6$state === void 0 ? null : _ref6$state;
              _context3.next = 4;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 4:
              _yield$_this$esDriver3 = _context3.sent;
              callWithRequest = _yield$_this$esDriver3.callWithRequest;
              params = {
                index: index.join(",")
              };
              if (state) params.body = {
                state: state
              };
              _context3.next = 10;
              return callWithRequest(req, "ism.retry", params);

            case 10:
              retryResponse = _context3.sent;
              return _context3.abrupt("return", {
                ok: true,
                response: {
                  failures: retryResponse.failures,
                  updatedIndices: retryResponse.updated_indices,
                  // TODO: remove ternary after fixing retry API to return empty array even if no failures
                  failedIndices: retryResponse.failed_indices ? retryResponse.failed_indices.map(function (failedIndex) {
                    return {
                      indexName: failedIndex.index_name,
                      indexUuid: failedIndex.index_uuid,
                      reason: failedIndex.reason
                    };
                  }) : []
                }
              });

            case 14:
              _context3.prev = 14;
              _context3.t0 = _context3["catch"](0);
              console.error("Index Management - ManagedIndexService - retryManagedIndexPolicy:", _context3.t0);
              return _context3.abrupt("return", {
                ok: false,
                error: _context3.t0.message
              });

            case 18:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, null, [[0, 14]]);
    }));

    return function (_x5, _x6) {
      return _ref5.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "changePolicy", /*#__PURE__*/function () {
    var _ref7 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(req, h) {
      var _ref8, indices, policyId, include, state, _yield$_this$esDriver4, callWithRequest, params, changeResponse;

      return _regenerator.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _ref8 = req.payload, indices = _ref8.indices, policyId = _ref8.policyId, include = _ref8.include, state = _ref8.state;
              _context4.next = 4;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 4:
              _yield$_this$esDriver4 = _context4.sent;
              callWithRequest = _yield$_this$esDriver4.callWithRequest;
              params = {
                index: indices.join(","),
                body: {
                  policy_id: policyId,
                  include: include,
                  state: state
                }
              };
              _context4.next = 9;
              return callWithRequest(req, "ism.change", params);

            case 9:
              changeResponse = _context4.sent;
              return _context4.abrupt("return", {
                ok: true,
                response: {
                  failures: changeResponse.failures,
                  updatedIndices: changeResponse.updated_indices,
                  failedIndices: changeResponse.failed_indices.map(function (failedIndex) {
                    return {
                      indexName: failedIndex.index_name,
                      indexUuid: failedIndex.index_uuid,
                      reason: failedIndex.reason
                    };
                  })
                }
              });

            case 13:
              _context4.prev = 13;
              _context4.t0 = _context4["catch"](0);
              console.error("Index Management - ManagedIndexService - changePolicy:", _context4.t0);
              return _context4.abrupt("return", {
                ok: false,
                error: _context4.t0.message
              });

            case 17:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4, null, [[0, 13]]);
    }));

    return function (_x7, _x8) {
      return _ref7.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "removePolicy", /*#__PURE__*/function () {
    var _ref9 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5(req, h) {
      var _ref10, indices, _yield$_this$esDriver5, callWithRequest, params, addResponse;

      return _regenerator.default.wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              _context5.prev = 0;
              _ref10 = req.payload, indices = _ref10.indices;
              _context5.next = 4;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 4:
              _yield$_this$esDriver5 = _context5.sent;
              callWithRequest = _yield$_this$esDriver5.callWithRequest;
              params = {
                index: indices.join(",")
              };
              _context5.next = 9;
              return callWithRequest(req, "ism.remove", params);

            case 9:
              addResponse = _context5.sent;
              return _context5.abrupt("return", {
                ok: true,
                response: {
                  failures: addResponse.failures,
                  updatedIndices: addResponse.updated_indices,
                  failedIndices: addResponse.failed_indices.map(function (failedIndex) {
                    return {
                      indexName: failedIndex.index_name,
                      indexUuid: failedIndex.index_uuid,
                      reason: failedIndex.reason
                    };
                  })
                }
              });

            case 13:
              _context5.prev = 13;
              _context5.t0 = _context5["catch"](0);
              console.error("Index Management - ManagedIndexService - removePolicy:", _context5.t0);
              return _context5.abrupt("return", {
                ok: false,
                error: _context5.t0.message
              });

            case 17:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5, null, [[0, 13]]);
    }));

    return function (_x9, _x10) {
      return _ref9.apply(this, arguments);
    };
  }());
  this.esDriver = esDriver;
} // TODO: Not finished, need UI page that uses this first
;

exports.default = ManagedIndexService;
module.exports = exports.default;