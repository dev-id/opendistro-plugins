"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../utils/constants");

var _helpers = require("../utils/helpers");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var PolicyService = function PolicyService(esDriver) {
  var _this = this;

  (0, _classCallCheck2.default)(this, PolicyService);
  (0, _defineProperty2.default)(this, "esDriver", void 0);
  (0, _defineProperty2.default)(this, "putPolicy", /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(req, h) {
      var id, _ref2, seqNo, primaryTerm, method, params, _yield$_this$esDriver, callWithRequest, response;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              id = req.params.id;
              _ref2 = req.query, seqNo = _ref2.seqNo, primaryTerm = _ref2.primaryTerm;
              method = "ism.putPolicy";
              params = {
                policyId: id,
                ifSeqNo: seqNo,
                ifPrimaryTerm: primaryTerm,
                body: JSON.stringify(req.payload)
              };

              if (seqNo === undefined || primaryTerm === undefined) {
                method = "ism.createPolicy";
                params = {
                  policyId: id,
                  body: JSON.stringify(req.payload)
                };
              }

              _context.next = 8;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 8:
              _yield$_this$esDriver = _context.sent;
              callWithRequest = _yield$_this$esDriver.callWithRequest;
              _context.next = 12;
              return callWithRequest(req, method, params);

            case 12:
              response = _context.sent;
              return _context.abrupt("return", {
                ok: true,
                response: response
              });

            case 16:
              _context.prev = 16;
              _context.t0 = _context["catch"](0);
              console.error("Index Management - PolicyService - putPolicy:", _context.t0);
              return _context.abrupt("return", {
                ok: false,
                error: _context.t0.message
              });

            case 20:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 16]]);
    }));

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "deletePolicy", /*#__PURE__*/function () {
    var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(req, h) {
      var id, params, _yield$_this$esDriver2, callWithRequest, response;

      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              id = req.params.id;
              params = {
                policyId: id
              };
              _context2.next = 5;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 5:
              _yield$_this$esDriver2 = _context2.sent;
              callWithRequest = _yield$_this$esDriver2.callWithRequest;
              _context2.next = 9;
              return callWithRequest(req, "ism.deletePolicy", params);

            case 9:
              response = _context2.sent;

              if (!(response.result !== "deleted")) {
                _context2.next = 12;
                break;
              }

              return _context2.abrupt("return", {
                ok: false,
                error: response.result
              });

            case 12:
              return _context2.abrupt("return", {
                ok: true,
                response: true
              });

            case 15:
              _context2.prev = 15;
              _context2.t0 = _context2["catch"](0);
              console.error("Index Management - PolicyService - deletePolicy:", _context2.t0);
              return _context2.abrupt("return", {
                ok: false,
                error: _context2.t0.message
              });

            case 19:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 15]]);
    }));

    return function (_x3, _x4) {
      return _ref3.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "getPolicy", /*#__PURE__*/function () {
    var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(req, h) {
      var id, params, _yield$_this$esDriver3, callWithRequest, getResponse, policy, seqNo, primaryTerm;

      return _regenerator.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              id = req.params.id;
              params = {
                policyId: id
              };
              _context3.next = 5;
              return _this.esDriver.getCluster(_constants.CLUSTER.ISM);

            case 5:
              _yield$_this$esDriver3 = _context3.sent;
              callWithRequest = _yield$_this$esDriver3.callWithRequest;
              _context3.next = 9;
              return callWithRequest(req, "ism.getPolicy", params);

            case 9:
              getResponse = _context3.sent;
              policy = _lodash.default.get(getResponse, "policy", null);
              seqNo = _lodash.default.get(getResponse, "_seq_no");
              primaryTerm = _lodash.default.get(getResponse, "_primary_term");

              if (!policy) {
                _context3.next = 17;
                break;
              }

              return _context3.abrupt("return", {
                ok: true,
                response: {
                  id: id,
                  seqNo: seqNo,
                  primaryTerm: primaryTerm,
                  policy: policy
                }
              });

            case 17:
              return _context3.abrupt("return", {
                ok: false,
                error: "Failed to load policy"
              });

            case 18:
              _context3.next = 24;
              break;

            case 20:
              _context3.prev = 20;
              _context3.t0 = _context3["catch"](0);
              console.error("Index Management - PolicyService - getPolicy:", _context3.t0);
              return _context3.abrupt("return", {
                ok: false,
                error: _context3.t0.message
              });

            case 24:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, null, [[0, 20]]);
    }));

    return function (_x5, _x6) {
      return _ref4.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "getPolicies", /*#__PURE__*/function () {
    var _ref5 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(req, h) {
      var _ref6, from, size, search, sortDirection, sortField, policySorts, params, _yield$_this$esDriver4, callWithRequest, searchResponse, totalPolicies, policies;

      return _regenerator.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _ref6 = req.query, from = _ref6.from, size = _ref6.size, search = _ref6.search, sortDirection = _ref6.sortDirection, sortField = _ref6.sortField;
              policySorts = {
                id: "policy.policy_id.keyword",
                "policy.policy.description": "policy.description.keyword",
                "policy.policy.last_updated_time": "policy.last_updated_time"
              };
              params = {
                index: _constants.INDEX.OPENDISTRO_ISM_CONFIG,
                seq_no_primary_term: true,
                body: {
                  size: size,
                  from: from,
                  sort: policySorts[sortField] ? [(0, _defineProperty2.default)({}, policySorts[sortField], sortDirection)] : [],
                  query: {
                    bool: {
                      filter: [{
                        exists: {
                          field: "policy"
                        }
                      }],
                      must: (0, _helpers.getMustQuery)("policy.policy_id", search)
                    }
                  }
                }
              };
              _context4.next = 6;
              return _this.esDriver.getCluster(_constants.CLUSTER.DATA);

            case 6:
              _yield$_this$esDriver4 = _context4.sent;
              callWithRequest = _yield$_this$esDriver4.callWithRequest;
              _context4.next = 10;
              return callWithRequest(req, "search", params);

            case 10:
              searchResponse = _context4.sent;
              totalPolicies = searchResponse.hits.total.value;
              policies = searchResponse.hits.hits.map(function (hit) {
                return {
                  seqNo: hit._seq_no,
                  primaryTerm: hit._primary_term,
                  id: hit._id,
                  policy: hit._source
                };
              });
              return _context4.abrupt("return", {
                ok: true,
                response: {
                  policies: policies,
                  totalPolicies: totalPolicies
                }
              });

            case 16:
              _context4.prev = 16;
              _context4.t0 = _context4["catch"](0);

              if (!(_context4.t0.statusCode === 404 && _context4.t0.body.error.type === "index_not_found_exception")) {
                _context4.next = 20;
                break;
              }

              return _context4.abrupt("return", {
                ok: true,
                response: {
                  policies: [],
                  totalPolicies: 0
                }
              });

            case 20:
              console.error("Index Management - PolicyService - getPolicies", _context4.t0);
              return _context4.abrupt("return", {
                ok: false,
                error: _context4.t0.message
              });

            case 22:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4, null, [[0, 16]]);
    }));

    return function (_x7, _x8) {
      return _ref5.apply(this, arguments);
    };
  }());
  this.esDriver = esDriver;
}
/**
 * Calls backend Put Policy API
 */
;

exports.default = PolicyService;
module.exports = exports.default;