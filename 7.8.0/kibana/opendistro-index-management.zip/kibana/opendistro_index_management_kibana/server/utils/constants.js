"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Setting = exports.INDEX = exports.CLUSTER = exports.DEFAULT_HEADERS = exports.API = exports.API_ROUTE_PREFIX = void 0;

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var API_ROUTE_PREFIX = "/_opendistro/_ism";
exports.API_ROUTE_PREFIX = API_ROUTE_PREFIX;
var API = {
  POLICY_BASE: "".concat(API_ROUTE_PREFIX, "/policies"),
  EXPLAIN_BASE: "".concat(API_ROUTE_PREFIX, "/explain"),
  RETRY_BASE: "".concat(API_ROUTE_PREFIX, "/retry"),
  ADD_POLICY_BASE: "".concat(API_ROUTE_PREFIX, "/add"),
  REMOVE_POLICY_BASE: "".concat(API_ROUTE_PREFIX, "/remove"),
  CHANGE_POLICY_BASE: "".concat(API_ROUTE_PREFIX, "/change_policy")
};
exports.API = API;
var DEFAULT_HEADERS = {
  "Content-Type": "application/json",
  Accept: "application/json"
};
exports.DEFAULT_HEADERS = DEFAULT_HEADERS;
var CLUSTER;
exports.CLUSTER = CLUSTER;

(function (CLUSTER) {
  CLUSTER["ADMIN"] = "admin";
  CLUSTER["ISM"] = "opendistro_ism";
  CLUSTER["DATA"] = "data";
})(CLUSTER || (exports.CLUSTER = CLUSTER = {}));

var INDEX;
exports.INDEX = INDEX;

(function (INDEX) {
  INDEX["OPENDISTRO_ISM_CONFIG"] = ".opendistro-ism-config";
})(INDEX || (exports.INDEX = INDEX = {}));

var Setting;
exports.Setting = Setting;

(function (Setting) {
  Setting["RolloverAlias"] = "opendistro.index_state_management.rollover_alias";
})(Setting || (exports.Setting = Setting = {}));