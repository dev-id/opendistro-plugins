"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "indices", {
  enumerable: true,
  get: function get() {
    return _indices.default;
  }
});
Object.defineProperty(exports, "policies", {
  enumerable: true,
  get: function get() {
    return _policies.default;
  }
});
Object.defineProperty(exports, "managedIndices", {
  enumerable: true,
  get: function get() {
    return _managedIndices.default;
  }
});

var _indices = _interopRequireDefault(require("./indices"));

var _policies = _interopRequireDefault(require("./policies"));

var _managedIndices = _interopRequireDefault(require("./managedIndices"));