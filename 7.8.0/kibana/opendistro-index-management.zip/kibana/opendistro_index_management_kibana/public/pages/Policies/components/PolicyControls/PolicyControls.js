"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _EuiRefreshPicker = _interopRequireDefault(require("../../../../temporary/EuiRefreshPicker"));

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var PolicyControls = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(PolicyControls, _Component);

  var _super = _createSuper(PolicyControls);

  function PolicyControls() {
    var _this;

    (0, _classCallCheck2.default)(this, PolicyControls);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      refreshInterval: 0,
      isPaused: true
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onRefreshChange", function (_ref) {
      var refreshInterval = _ref.refreshInterval,
          isPaused = _ref.isPaused;

      _this.setState({
        isPaused: isPaused,
        refreshInterval: refreshInterval
      });
    });
    return _this;
  }

  (0, _createClass2.default)(PolicyControls, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          activePage = _this$props.activePage,
          pageCount = _this$props.pageCount,
          search = _this$props.search,
          onSearchChange = _this$props.onSearchChange,
          onPageClick = _this$props.onPageClick,
          onRefresh = _this$props.onRefresh;
      var _this$state = this.state,
          refreshInterval = _this$state.refreshInterval,
          isPaused = _this$state.isPaused;
      return /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        style: {
          padding: "0px 5px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, /*#__PURE__*/_react.default.createElement(_eui.EuiFieldSearch, {
        fullWidth: true,
        value: search,
        placeholder: "Search",
        onChange: onSearchChange
      })), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false,
        style: {
          maxWidth: 250
        }
      }, /*#__PURE__*/_react.default.createElement(_EuiRefreshPicker.default, {
        isPaused: isPaused,
        refreshInterval: refreshInterval,
        onRefreshChange: this.onRefreshChange,
        onRefresh: onRefresh
      })), pageCount > 1 && /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false,
        style: {
          justifyContent: "center"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiPagination, {
        pageCount: pageCount,
        activePage: activePage,
        onPageClick: onPageClick,
        "data-test-subj": "policyControlsPagination"
      })));
    }
  }]);
  return PolicyControls;
}(_react.Component);

exports.default = PolicyControls;
module.exports = exports.default;