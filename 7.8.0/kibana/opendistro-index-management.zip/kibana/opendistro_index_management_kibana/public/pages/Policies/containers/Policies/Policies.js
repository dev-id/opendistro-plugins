"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _chrome = _interopRequireDefault(require("ui/chrome"));

var _notify = require("ui/notify");

var _queryString = _interopRequireDefault(require("query-string"));

var _eui = require("@elastic/eui");

var _lodash = _interopRequireDefault(require("lodash"));

var _ContentPanel = require("../../../../components/ContentPanel");

var _PolicyControls = _interopRequireDefault(require("../../components/PolicyControls"));

var _PolicyEmptyPrompt = _interopRequireDefault(require("../../components/PolicyEmptyPrompt"));

var _PolicyModal = _interopRequireDefault(require("../../../../components/PolicyModal"));

var _Modal = require("../../../../components/Modal");

var _constants = require("../../utils/constants");

var _helpers = require("../../utils/helpers");

var _constants2 = require("../../../../utils/constants");

var _helpers2 = require("../../../../utils/helpers");

var _ConfirmationModal = _interopRequireDefault(require("../../../../components/ConfirmationModal"));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Policies = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(Policies, _Component);

  var _super = _createSuper(Policies);

  function Policies(props) {
    var _this;

    (0, _classCallCheck2.default)(this, Policies);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "columns", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getPolicies", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _this$props, policyService, history, queryParamsString, getPoliciesResponse, _getPoliciesResponse$, policies, totalPolicies;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this.setState({
                loadingPolicies: true
              });

              _context.prev = 1;
              _this$props = _this.props, policyService = _this$props.policyService, history = _this$props.history;
              queryParamsString = _queryString.default.stringify(Policies.getQueryObjectFromState(_this.state));
              history.replace(_objectSpread({}, _this.props.location, {
                search: queryParamsString
              }));
              _context.next = 7;
              return policyService.getPolicies(queryParamsString);

            case 7:
              getPoliciesResponse = _context.sent;

              if (getPoliciesResponse.ok) {
                _getPoliciesResponse$ = getPoliciesResponse.response, policies = _getPoliciesResponse$.policies, totalPolicies = _getPoliciesResponse$.totalPolicies;

                _this.setState({
                  policies: policies,
                  totalPolicies: totalPolicies
                });
              } else {
                _notify.toastNotifications.addDanger(getPoliciesResponse.error);
              }

              _context.next = 14;
              break;

            case 11:
              _context.prev = 11;
              _context.t0 = _context["catch"](1);

              _notify.toastNotifications.addDanger((0, _helpers2.getErrorMessage)(_context.t0, "There was a problem loading the policies"));

            case 14:
              _this.setState({
                loadingPolicies: false
              });

            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[1, 11]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "deletePolicy", /*#__PURE__*/function () {
      var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(policyId) {
        var policyService, deletePolicyResponse;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                policyService = _this.props.policyService;
                _context2.prev = 1;
                _context2.next = 4;
                return policyService.deletePolicy(policyId);

              case 4:
                deletePolicyResponse = _context2.sent;

                if (!deletePolicyResponse.ok) {
                  _context2.next = 10;
                  break;
                }

                _notify.toastNotifications.addSuccess("Deleted the policy: ".concat(policyId));

                return _context2.abrupt("return", true);

              case 10:
                _notify.toastNotifications.addDanger("Failed to delete the policy, ".concat(deletePolicyResponse.error));

              case 11:
                _context2.next = 16;
                break;

              case 13:
                _context2.prev = 13;
                _context2.t0 = _context2["catch"](1);

                _notify.toastNotifications.addDanger((0, _helpers2.getErrorMessage)(_context2.t0, "There was a problem deleting the policy"));

              case 16:
                return _context2.abrupt("return", false);

              case 17:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[1, 13]]);
      }));

      return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onTableChange", function (_ref3) {
      var tablePage = _ref3.page,
          sort = _ref3.sort;
      var page = tablePage.index,
          size = tablePage.size;
      var sortField = sort.field,
          sortDirection = sort.direction;

      _this.setState({
        from: page * size,
        size: size,
        sortField: sortField,
        sortDirection: sortDirection
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSelectionChange", function (selectedItems) {
      _this.setState({
        selectedItems: selectedItems
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSearchChange", function (e) {
      _this.setState({
        from: 0,
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onPageClick", function (page) {
      var size = _this.state.size;

      _this.setState({
        from: page * size
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "resetFilters", function () {
      _this.setState({
        search: _constants.DEFAULT_QUERY_PARAMS.search
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickEdit", function () {
      var _this$state$selectedI = (0, _slicedToArray2.default)(_this.state.selectedItems, 1),
          id = _this$state$selectedI[0].id;

      if (id) _this.props.history.push("".concat(_constants2.ROUTES.EDIT_POLICY, "?id=").concat(id));
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickCreate", function () {
      _this.props.history.push(_constants2.ROUTES.CREATE_POLICY);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickDelete", /*#__PURE__*/function () {
      var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(policyIds) {
        var deletePromises, deleted;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (policyIds.length) {
                  _context3.next = 2;
                  break;
                }

                return _context3.abrupt("return");

              case 2:
                deletePromises = policyIds.map(function (policyId) {
                  return _this.deletePolicy(policyId);
                });
                _context3.next = 5;
                return Promise.all(deletePromises);

              case 5:
                deleted = _context3.sent.reduce(function (deleted, result) {
                  return deleted && result;
                });

                if (!deleted) {
                  _context3.next = 9;
                  break;
                }

                _context3.next = 9;
                return _this.getPolicies();

              case 9:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));

      return function (_x2) {
        return _ref4.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickModalEdit", function (item, onClose) {
      onClose();
      if (!item || !item.id) return;

      _this.props.history.push("".concat(_constants2.ROUTES.EDIT_POLICY, "?id=").concat(item.id));
    });

    var _getURLQueryParams = (0, _helpers.getURLQueryParams)(_this.props.location),
        from = _getURLQueryParams.from,
        _size = _getURLQueryParams.size,
        search = _getURLQueryParams.search,
        _sortField = _getURLQueryParams.sortField,
        _sortDirection = _getURLQueryParams.sortDirection;

    _this.state = {
      totalPolicies: 0,
      from: from,
      size: _size,
      search: search,
      sortField: _sortField,
      sortDirection: _sortDirection,
      selectedItems: [],
      policies: [],
      loadingPolicies: true
    };
    _this.getPolicies = _lodash.default.debounce(_this.getPolicies, 500, {
      leading: true
    });
    _this.columns = [{
      field: "id",
      name: "Policy",
      sortable: true,
      truncateText: true,
      textOnly: true,
      width: "150px",
      render: function render(name, item) {
        return /*#__PURE__*/_react.default.createElement(_Modal.ModalConsumer, null, function (_ref5) {
          var onShow = _ref5.onShow,
              onClose = _ref5.onClose;
          return /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
            onClick: function onClick() {
              return onShow(_PolicyModal.default, {
                policyId: item.id,
                policy: item.policy,
                onEdit: function onEdit() {
                  return _this.onClickModalEdit(item, onClose);
                }
              });
            }
          }, name);
        });
      }
    }, {
      field: "policy.policy.description",
      name: "Description",
      sortable: true,
      truncateText: true,
      textOnly: true,
      width: "150px"
    }, {
      field: "policy.policy.last_updated_time",
      name: "Last updated time",
      sortable: true,
      truncateText: false,
      render: _helpers.renderTime,
      dataType: "date",
      width: "150px"
    }];
    return _this;
  }

  (0, _createClass2.default)(Policies, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _chrome.default.breadcrumbs.set([_constants2.BREADCRUMBS.INDEX_MANAGEMENT, _constants2.BREADCRUMBS.INDEX_POLICIES]);

                _context4.next = 3;
                return this.getPolicies();

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5(prevProps, prevState) {
        var prevQuery, currQuery;
        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                prevQuery = Policies.getQueryObjectFromState(prevState);
                currQuery = Policies.getQueryObjectFromState(this.state);

                if (_lodash.default.isEqual(prevQuery, currQuery)) {
                  _context5.next = 5;
                  break;
                }

                _context5.next = 5;
                return this.getPolicies();

              case 5:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function componentDidUpdate(_x3, _x4) {
        return _componentDidUpdate.apply(this, arguments);
      }

      return componentDidUpdate;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state = this.state,
          totalPolicies = _this$state.totalPolicies,
          from = _this$state.from,
          size = _this$state.size,
          search = _this$state.search,
          sortField = _this$state.sortField,
          sortDirection = _this$state.sortDirection,
          selectedItems = _this$state.selectedItems,
          policies = _this$state.policies,
          loadingPolicies = _this$state.loadingPolicies;
      var filterIsApplied = !!search;
      var page = Math.floor(from / size);
      var pagination = {
        pageIndex: page,
        pageSize: size,
        pageSizeOptions: _constants.DEFAULT_PAGE_SIZE_OPTIONS,
        totalItemCount: totalPolicies
      };
      var sorting = {
        sort: {
          direction: sortDirection,
          field: sortField
        }
      };
      var selection = {
        onSelectionChange: this.onSelectionChange
      };
      var actions = [{
        text: "Delete",
        buttonProps: {
          disabled: !selectedItems.length
        },
        modal: {
          onClickModal: function onClickModal(onShow) {
            return function () {
              return onShow(_ConfirmationModal.default, {
                title: "Delete ".concat(selectedItems.length === 1 ? selectedItems[0].id : "".concat(selectedItems.length, " policies")),
                bodyMessage: "Delete ".concat(selectedItems.length === 1 ? selectedItems[0].id : "".concat(selectedItems.length, " policies"), " permanently? This action cannot be undone."),
                actionMessage: "Delete",
                onAction: function onAction() {
                  return _this2.onClickDelete(selectedItems.map(function (item) {
                    return item.id;
                  }));
                }
              });
            };
          }
        }
      }, {
        text: "Edit",
        buttonProps: {
          disabled: selectedItems.length !== 1,
          onClick: this.onClickEdit
        }
      }, {
        text: "Create policy",
        buttonProps: {
          onClick: this.onClickCreate
        }
      }];
      return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
        actions: /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanelActions, {
          actions: actions
        }),
        bodyStyles: {
          padding: "initial"
        },
        title: "Index policies"
      }, /*#__PURE__*/_react.default.createElement(_PolicyControls.default, {
        activePage: page,
        pageCount: Math.ceil(totalPolicies / size) || 1,
        search: search,
        onSearchChange: this.onSearchChange,
        onPageClick: this.onPageClick,
        onRefresh: this.getPolicies
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
        margin: "xs"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiBasicTable, {
        columns: this.columns,
        isSelectable: true,
        itemId: "id",
        items: policies,
        noItemsMessage: /*#__PURE__*/_react.default.createElement(_PolicyEmptyPrompt.default, {
          filterIsApplied: filterIsApplied,
          loading: loadingPolicies,
          resetFilters: this.resetFilters
        }),
        onChange: this.onTableChange,
        pagination: pagination,
        selection: selection,
        sorting: sorting
      }));
    }
  }], [{
    key: "getQueryObjectFromState",
    value: function getQueryObjectFromState(_ref6) {
      var from = _ref6.from,
          size = _ref6.size,
          search = _ref6.search,
          sortField = _ref6.sortField,
          sortDirection = _ref6.sortDirection;
      return {
        from: from,
        size: size,
        search: search,
        sortField: sortField,
        sortDirection: sortDirection
      };
    }
  }]);
  return Policies;
}(_react.Component);

exports.default = Policies;
module.exports = exports.default;