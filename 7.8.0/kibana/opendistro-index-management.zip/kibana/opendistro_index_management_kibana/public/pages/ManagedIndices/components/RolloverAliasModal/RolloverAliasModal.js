"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _notify = require("ui/notify");

var _eui = require("@elastic/eui");

var _helpers = require("../../../../utils/helpers");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var RolloverAliasModal = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(RolloverAliasModal, _Component);

  var _super = _createSuper(RolloverAliasModal);

  function RolloverAliasModal() {
    var _this;

    (0, _classCallCheck2.default)(this, RolloverAliasModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      rolloverAlias: ""
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onEditRolloverAlias", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _this$props, onClose, index, indexService, rolloverAlias, response;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this$props = _this.props, onClose = _this$props.onClose, index = _this$props.index, indexService = _this$props.services.indexService;
              rolloverAlias = _this.state.rolloverAlias;
              _context.prev = 2;
              _context.next = 5;
              return indexService.editRolloverAlias(index, rolloverAlias);

            case 5:
              response = _context.sent;

              if (response.ok) {
                if (response.response.acknowledged) {
                  _notify.toastNotifications.addSuccess("Edited rollover alias on ".concat(index));
                } else {
                  _notify.toastNotifications.addDanger("Failed to edit rollover alias on ".concat(index));
                }
              } else {
                _notify.toastNotifications.addDanger(response.error);
              }

              onClose();
              _context.next = 13;
              break;

            case 10:
              _context.prev = 10;
              _context.t0 = _context["catch"](2);

              _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context.t0, "There was a problem editing rollover alias on ".concat(index)));

            case 13:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[2, 10]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChange", function (e) {
      _this.setState({
        rolloverAlias: e.target.value
      });
    });
    return _this;
  }

  (0, _createClass2.default)(RolloverAliasModal, [{
    key: "render",
    value: function render() {
      var rolloverAlias = this.state.rolloverAlias;
      var onClose = this.props.onClose;
      return /*#__PURE__*/_react.default.createElement(_eui.EuiOverlayMask, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModal, {
        onCancel: onClose,
        onClose: onClose
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeader, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeaderTitle, null, "Edit rollover alias")), /*#__PURE__*/_react.default.createElement(_eui.EuiModalBody, null, /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "Rollover alias",
        helpText: "A rollover alias is required when using the rollover action."
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFieldText, {
        placeholder: "Rollover alias",
        value: rolloverAlias,
        onChange: this.onChange
      }))), /*#__PURE__*/_react.default.createElement(_eui.EuiModalFooter, null, /*#__PURE__*/_react.default.createElement(_eui.EuiButtonEmpty, {
        onClick: onClose,
        "data-test-subj": "editRolloverAliasModalCloseButton"
      }, "Close"), /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        onClick: this.onEditRolloverAlias,
        disabled: !rolloverAlias,
        fill: true,
        "data-test-subj": "editRolloverAliasModalAddButton"
      }, "Edit"))));
    }
  }]);
  return RolloverAliasModal;
}(_react.Component);

exports.default = RolloverAliasModal;
module.exports = exports.default;