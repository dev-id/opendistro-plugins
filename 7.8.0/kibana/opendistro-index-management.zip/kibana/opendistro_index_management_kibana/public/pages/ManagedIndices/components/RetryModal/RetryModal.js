"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));

var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _notify = require("ui/notify");

var _eui = require("@elastic/eui");

var _helpers = require("../../../../utils/helpers");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Radio;

(function (Radio) {
  Radio["Current"] = "current";
  Radio["State"] = "state";
})(Radio || (Radio = {}));

var RetryModal = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(RetryModal, _Component);

  var _super = _createSuper(RetryModal);

  function RetryModal() {
    var _this;

    (0, _classCallCheck2.default)(this, RetryModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      radioIdSelected: Radio.Current,
      stateSelected: "",
      stateOptions: []
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "initOptions", function () {
      var retryItems = _this.props.retryItems;
      if (!retryItems.length) return; // we will use this first item as the base set of states
      // if we ever encounter an item with no policy, then simply return early
      // otherwise take the intersections of all next retry item states
      // until we have a final list of common states

      var firstRetryItem = retryItems[0];
      if (!firstRetryItem.policy || !firstRetryItem.policy.states) return;
      var states = new Set(firstRetryItem.policy.states.map(function (state) {
        return state.name;
      }));

      var _loop = function _loop(i) {
        // if we ever end up with no states just return early
        if (!states.size) return {
          v: void 0
        };
        var retryItem = retryItems[i];
        if (!retryItem.policy || !retryItem.policy.states) return {
          v: void 0
        };
        var tempStates = new Set(retryItem.policy.states.map(function (state) {
          return state.name;
        })); // take intersection of two state sets

        states = new Set((0, _toConsumableArray2.default)(states).filter(function (state) {
          return tempStates.has(state);
        }));
      };

      for (var i = 1; i < retryItems.length; i++) {
        var _ret = _loop(i);

        if ((0, _typeof2.default)(_ret) === "object") return _ret.v;
      }

      var stateOptions = (0, _toConsumableArray2.default)(states).map(function (state) {
        return {
          value: state,
          text: state
        };
      });

      _this.setState({
        stateOptions: stateOptions
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onRetry", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _this$state, radioIdSelected, stateSelected, _this$props, retryItems, onClose, managedIndexService, indices, state, response, _response$response, updatedIndices, failedIndices, failures;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this$state = _this.state, radioIdSelected = _this$state.radioIdSelected, stateSelected = _this$state.stateSelected;
              _this$props = _this.props, retryItems = _this$props.retryItems, onClose = _this$props.onClose, managedIndexService = _this$props.services.managedIndexService;
              _context.prev = 2;
              indices = retryItems.map(function (item) {
                return item.index;
              });
              state = radioIdSelected == Radio.State ? stateSelected : null;
              _context.next = 7;
              return managedIndexService.retryManagedIndexPolicy(indices, state);

            case 7:
              response = _context.sent;

              if (response.ok) {
                _response$response = response.response, updatedIndices = _response$response.updatedIndices, failedIndices = _response$response.failedIndices, failures = _response$response.failures;

                if (failures) {
                  _notify.toastNotifications.addDanger("Failed to retry: ".concat(failedIndices.map(function (failedIndex) {
                    return "[".concat(failedIndex.indexName, ", ").concat(failedIndex.reason, "]");
                  }).join(", ")));
                }

                if (updatedIndices) {
                  _notify.toastNotifications.addSuccess("Retried ".concat(updatedIndices, " managed indices"));
                }
              } else {
                _notify.toastNotifications.addDanger(response.error);
              }

              onClose();
              _context.next = 15;
              break;

            case 12:
              _context.prev = 12;
              _context.t0 = _context["catch"](2);

              _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context.t0, "There was a problem retrying managed indices"));

            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[2, 12]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChange", function (optionId) {
      _this.setState({
        radioIdSelected: optionId
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSelectChange", function (e) {
      _this.setState({
        stateSelected: e.target.value
      });
    });
    return _this;
  }

  (0, _createClass2.default)(RetryModal, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.initOptions();
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state2 = this.state,
          radioIdSelected = _this$state2.radioIdSelected,
          stateSelected = _this$state2.stateSelected,
          stateOptions = _this$state2.stateOptions;
      var _this$props2 = this.props,
          onClose = _this$props2.onClose,
          retryItems = _this$props2.retryItems;
      var currentRadio = {
        id: Radio.Current,
        label: "Retry policy from current action"
      };
      var stateRadio = {
        id: Radio.State,
        label: "Retry policy from selected state",
        disabled: !stateOptions.length
      };
      var radioOptions = [currentRadio, stateRadio];
      return /*#__PURE__*/_react.default.createElement(_eui.EuiOverlayMask, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModal, {
        onCancel: onClose,
        onClose: onClose
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeader, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeaderTitle, null, "Retry policy")), /*#__PURE__*/_react.default.createElement(_eui.EuiModalBody, null, /*#__PURE__*/_react.default.createElement(_eui.EuiRadioGroup, {
        options: radioOptions,
        idSelected: radioIdSelected,
        onChange: this.onChange
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "s"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "Start state",
        helpText: "Only common states shared across all selected indices are available"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiSelect, {
        disabled: radioIdSelected !== Radio.State,
        options: stateOptions,
        value: stateSelected,
        onChange: this.onSelectChange,
        "aria-label": "Retry failed policy from"
      }))), /*#__PURE__*/_react.default.createElement(_eui.EuiModalFooter, null, /*#__PURE__*/_react.default.createElement(_eui.EuiButtonEmpty, {
        onClick: onClose,
        "data-test-subj": "retryModalCloseButton"
      }, "Close"), /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        onClick: this.onRetry,
        disabled: !retryItems.length,
        fill: true,
        "data-test-subj": "retryModalRetryButton"
      }, "Retry"))));
    }
  }]);
  return RetryModal;
}(_react.Component);

exports.default = RetryModal;
module.exports = exports.default;