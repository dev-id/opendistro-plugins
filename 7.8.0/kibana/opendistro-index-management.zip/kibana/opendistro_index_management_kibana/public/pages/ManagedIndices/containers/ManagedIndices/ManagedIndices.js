"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _notify = require("ui/notify");

var _chrome = _interopRequireDefault(require("ui/chrome"));

var _eui = require("@elastic/eui");

var _queryString = _interopRequireDefault(require("query-string"));

var _lodash = _interopRequireDefault(require("lodash"));

var _ContentPanel = require("../../../../components/ContentPanel");

var _ManagedIndexControls = _interopRequireDefault(require("../../components/ManagedIndexControls"));

var _ManagedIndexEmptyPrompt = _interopRequireDefault(require("../../components/ManagedIndexEmptyPrompt"));

var _constants = require("../../utils/constants");

var _constants2 = require("../../../../utils/constants");

var _InfoModal = _interopRequireDefault(require("../../components/InfoModal"));

var _PolicyModal = _interopRequireDefault(require("../../../../components/PolicyModal"));

var _Modal = require("../../../../components/Modal");

var _helpers = require("../../utils/helpers");

var _helpers2 = require("../../../../utils/helpers");

var _ConfirmationModal = _interopRequireDefault(require("../../../../components/ConfirmationModal"));

var _RetryModal = _interopRequireDefault(require("../../components/RetryModal"));

var _RolloverAliasModal = _interopRequireDefault(require("../../components/RolloverAliasModal"));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var ManagedIndices = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(ManagedIndices, _Component);

  var _super = _createSuper(ManagedIndices);

  function ManagedIndices(props) {
    var _this;

    (0, _classCallCheck2.default)(this, ManagedIndices);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "columns", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "renderPolicyId", function (policyId, item) {
      var errorMessage = undefined;

      if (!item.policy) {
        if (!item.managedIndexMetaData) errorMessage = "Still initializing, please wait a moment";else errorMessage = "Failed to load the policy: ".concat(item.policyId);
      }

      return /*#__PURE__*/_react.default.createElement(_Modal.ModalConsumer, null, function (_ref) {
        var onShow = _ref.onShow,
            onClose = _ref.onClose;
        return /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
          onClick: function onClick() {
            return onShow(_PolicyModal.default, {
              policyId: policyId,
              policy: item.policy,
              onEdit: function onEdit() {
                return _this.onClickModalEdit(item, onClose);
              },
              errorMessage: errorMessage
            });
          }
        }, policyId);
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getManagedIndices", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _this$props, managedIndexService, history, queryParamsString, getManagedIndicesResponse, _getManagedIndicesRes, managedIndices, totalManagedIndices;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this.setState({
                loadingManagedIndices: true
              });

              _context.prev = 1;
              _this$props = _this.props, managedIndexService = _this$props.managedIndexService, history = _this$props.history;
              queryParamsString = _queryString.default.stringify(ManagedIndices.getQueryObjectFromState(_this.state));
              history.replace(_objectSpread({}, _this.props.location, {
                search: queryParamsString
              }));
              _context.next = 7;
              return managedIndexService.getManagedIndices(queryParamsString);

            case 7:
              getManagedIndicesResponse = _context.sent;

              if (getManagedIndicesResponse.ok) {
                _getManagedIndicesRes = getManagedIndicesResponse.response, managedIndices = _getManagedIndicesRes.managedIndices, totalManagedIndices = _getManagedIndicesRes.totalManagedIndices;

                _this.setState({
                  managedIndices: managedIndices,
                  totalManagedIndices: totalManagedIndices
                });
              } else {
                _notify.toastNotifications.addDanger(getManagedIndicesResponse.error);
              }

              _context.next = 14;
              break;

            case 11:
              _context.prev = 11;
              _context.t0 = _context["catch"](1);

              _notify.toastNotifications.addDanger((0, _helpers2.getErrorMessage)(_context.t0, "There was a problem loading the managed indices"));

            case 14:
              _this.setState({
                loadingManagedIndices: false
              });

            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[1, 11]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickRemovePolicy", /*#__PURE__*/function () {
      var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(indices) {
        var managedIndexService, removePolicyResponse, _removePolicyResponse, updatedIndices, failedIndices, failures;

        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;

                if (indices.length) {
                  _context2.next = 3;
                  break;
                }

                return _context2.abrupt("return");

              case 3:
                managedIndexService = _this.props.managedIndexService;
                _context2.next = 6;
                return managedIndexService.removePolicy(indices);

              case 6:
                removePolicyResponse = _context2.sent;

                if (removePolicyResponse.ok) {
                  _removePolicyResponse = removePolicyResponse.response, updatedIndices = _removePolicyResponse.updatedIndices, failedIndices = _removePolicyResponse.failedIndices, failures = _removePolicyResponse.failures;

                  if (updatedIndices) {
                    _notify.toastNotifications.addSuccess("Removed policy from ".concat(updatedIndices, " managed indices"));
                  }

                  if (failures) {
                    _notify.toastNotifications.addDanger("Failed to remove policy from ".concat(failedIndices.map(function (failedIndex) {
                      return "[".concat(failedIndex.indexName, ", ").concat(failedIndex.reason, "]");
                    }).join(", ")));
                  }
                } else {
                  _notify.toastNotifications.addDanger(removePolicyResponse.error);
                }

                _context2.next = 13;
                break;

              case 10:
                _context2.prev = 10;
                _context2.t0 = _context2["catch"](0);

                _notify.toastNotifications.addDanger((0, _helpers2.getErrorMessage)(_context2.t0, "There was a problem removing the policies"));

              case 13:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 10]]);
      }));

      return function (_x) {
        return _ref3.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onTableChange", function (_ref4) {
      var tablePage = _ref4.page,
          sort = _ref4.sort;
      var page = tablePage.index,
          size = tablePage.size;
      var sortField = sort.field,
          sortDirection = sort.direction;

      _this.setState({
        from: page * size,
        size: size,
        sortField: sortField,
        sortDirection: sortDirection
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSelectionChange", function (selectedItems) {
      _this.setState({
        selectedItems: selectedItems
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSearchChange", function (e) {
      _this.setState({
        from: 0,
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onPageClick", function (page) {
      var size = _this.state.size;

      _this.setState({
        from: page * size
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClickModalEdit", function (item, onClose) {
      onClose();
      if (!item || !item.policyId) return;

      _this.props.history.push("".concat(_constants2.ROUTES.EDIT_POLICY, "?id=").concat(item.policyId));
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "resetFilters", function () {
      _this.setState({
        search: _constants.DEFAULT_QUERY_PARAMS.search
      });
    });

    var _getURLQueryParams = (0, _helpers.getURLQueryParams)(_this.props.location),
        from = _getURLQueryParams.from,
        _size = _getURLQueryParams.size,
        search = _getURLQueryParams.search,
        _sortField = _getURLQueryParams.sortField,
        _sortDirection = _getURLQueryParams.sortDirection;

    _this.state = {
      totalManagedIndices: 0,
      from: from,
      size: _size,
      search: search,
      sortField: _sortField,
      sortDirection: _sortDirection,
      selectedItems: [],
      managedIndices: [],
      loadingManagedIndices: true
    };
    _this.getManagedIndices = _lodash.default.debounce(_this.getManagedIndices, 500, {
      leading: true
    });
    _this.columns = [{
      field: "index",
      name: "Index",
      sortable: true,
      truncateText: true,
      textOnly: true,
      width: "150px",
      render: function render(index) {
        return /*#__PURE__*/_react.default.createElement("span", {
          title: index
        }, index);
      }
    }, {
      field: "policyId",
      name: "Policy",
      sortable: true,
      truncateText: true,
      textOnly: true,
      width: "150px",
      render: _this.renderPolicyId
    }, {
      field: "managedIndexMetaData.state.name",
      name: "State",
      sortable: false,
      truncateText: false,
      width: "150px",
      // @ts-ignore
      render: function render(state) {
        return state || _constants2.DEFAULT_EMPTY_DATA;
      }
    }, {
      field: "managedIndexMetaData.action.name",
      name: "Action",
      sortable: false,
      truncateText: false,
      width: "150px",
      // @ts-ignore
      render: function render(action) {
        return _constants.ACTIONS[action] || _constants2.DEFAULT_EMPTY_DATA;
      }
    }, {
      field: "managedIndexMetaData.info",
      name: "Info",
      sortable: false,
      truncateText: true,
      textOnly: true,
      width: "150px",
      render: function render(info) {
        return /*#__PURE__*/_react.default.createElement(_Modal.ModalConsumer, null, function (_ref5) {
          var onShow = _ref5.onShow;
          return /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
            onClick: function onClick() {
              return onShow(_InfoModal.default, {
                info: info
              });
            }
          }, _lodash.default.get(info, "message", _constants2.DEFAULT_EMPTY_DATA));
        });
      }
    }, {
      field: "index",
      // we don't care about the field as we're using the whole item in render
      name: "Status",
      sortable: false,
      truncateText: false,
      width: "150px",
      render: function render(index, item) {
        var managedIndexMetaData = item.managedIndexMetaData;
        if (!managedIndexMetaData) return "Initializing";
        var policyCompleted = managedIndexMetaData.policyCompleted,
            retryInfo = managedIndexMetaData.retryInfo,
            action = managedIndexMetaData.action;
        if (policyCompleted) return "Completed";
        if (retryInfo && retryInfo.failed) return "Failed";
        if (action && action.failed) return "Failed";
        return "Running";
      }
    }];
    return _this;
  }

  (0, _createClass2.default)(ManagedIndices, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _chrome.default.breadcrumbs.set([_constants2.BREADCRUMBS.INDEX_MANAGEMENT, _constants2.BREADCRUMBS.MANAGED_INDICES]);

                _context3.next = 3;
                return this.getManagedIndices();

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(prevProps, prevState) {
        var prevQuery, currQuery;
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                prevQuery = ManagedIndices.getQueryObjectFromState(prevState);
                currQuery = ManagedIndices.getQueryObjectFromState(this.state);

                if (_lodash.default.isEqual(prevQuery, currQuery)) {
                  _context4.next = 5;
                  break;
                }

                _context4.next = 5;
                return this.getManagedIndices();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function componentDidUpdate(_x2, _x3) {
        return _componentDidUpdate.apply(this, arguments);
      }

      return componentDidUpdate;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state = this.state,
          totalManagedIndices = _this$state.totalManagedIndices,
          from = _this$state.from,
          size = _this$state.size,
          search = _this$state.search,
          sortField = _this$state.sortField,
          sortDirection = _this$state.sortDirection,
          selectedItems = _this$state.selectedItems,
          managedIndices = _this$state.managedIndices,
          loadingManagedIndices = _this$state.loadingManagedIndices;
      var filterIsApplied = !!search;
      var page = Math.floor(from / size);
      var pagination = {
        pageIndex: page,
        pageSize: size,
        pageSizeOptions: _constants.DEFAULT_PAGE_SIZE_OPTIONS,
        totalItemCount: totalManagedIndices
      };
      var sorting = {
        sort: {
          direction: sortDirection,
          field: sortField
        }
      };
      var selection = {
        onSelectionChange: this.onSelectionChange
      };
      var isRetryDisabled = !selectedItems.length || selectedItems.some(function (item) {
        if (!item.managedIndexMetaData) return true;
        var _item$managedIndexMet = item.managedIndexMetaData,
            retryInfo = _item$managedIndexMet.retryInfo,
            action = _item$managedIndexMet.action;
        return !(retryInfo && retryInfo.failed) && !(action && action.failed);
      });
      var actions = [{
        text: "Edit rollover alias",
        buttonProps: {
          disabled: selectedItems.length !== 1
        },
        modal: {
          onClickModal: function onClickModal(onShow) {
            return function () {
              return onShow(_RolloverAliasModal.default, {
                index: selectedItems[0].index
              });
            };
          }
        }
      }, {
        text: "Remove policy",
        buttonProps: {
          disabled: !selectedItems.length
        },
        modal: {
          onClickModal: function onClickModal(onShow) {
            return function () {
              return onShow(_ConfirmationModal.default, {
                title: "Remove ".concat(selectedItems.length === 1 ? "policy from ".concat(selectedItems[0].index) : "policies from ".concat(selectedItems.length, " indices")),
                bodyMessage: "Remove ".concat(selectedItems.length === 1 ? "policy from ".concat(selectedItems[0].index) : "policies from ".concat(selectedItems.length, " indices"), " permanently? This action cannot be undone."),
                actionMessage: "Remove",
                onAction: function onAction() {
                  return _this2.onClickRemovePolicy(selectedItems.map(function (item) {
                    return item.index;
                  }));
                }
              });
            };
          }
        }
      }, {
        text: "Retry policy",
        buttonProps: {
          disabled: isRetryDisabled
        },
        modal: {
          onClickModal: function onClickModal(onShow) {
            return function () {
              return onShow(_RetryModal.default, {
                retryItems: _lodash.default.cloneDeep(selectedItems)
              });
            };
          }
        }
      }];
      return /*#__PURE__*/_react.default.createElement("div", {
        style: {
          padding: "0px 25px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        alignItems: "center"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, /*#__PURE__*/_react.default.createElement(_eui.EuiTitle, {
        size: "l"
      }, /*#__PURE__*/_react.default.createElement("h1", null, "Managed Indices"))), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        href: "".concat(_constants2.PLUGIN_NAME, "#/change-policy"),
        "data-test-subj": "changePolicyButton"
      }, "Change policy"))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
        actions: /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanelActions, {
          actions: actions
        }),
        bodyStyles: {
          padding: "initial"
        },
        title: "Indices"
      }, /*#__PURE__*/_react.default.createElement(_ManagedIndexControls.default, {
        activePage: page,
        pageCount: Math.ceil(totalManagedIndices / size) || 1,
        search: search,
        onSearchChange: this.onSearchChange,
        onPageClick: this.onPageClick,
        onRefresh: this.getManagedIndices
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
        margin: "xs"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiBasicTable, {
        columns: this.columns,
        isSelectable: true,
        itemId: "index",
        items: managedIndices,
        noItemsMessage: /*#__PURE__*/_react.default.createElement(_ManagedIndexEmptyPrompt.default, {
          filterIsApplied: filterIsApplied,
          loading: loadingManagedIndices,
          resetFilters: this.resetFilters
        }),
        onChange: this.onTableChange,
        pagination: pagination,
        selection: selection,
        sorting: sorting
      })));
    }
  }], [{
    key: "getQueryObjectFromState",
    value: function getQueryObjectFromState(_ref6) {
      var from = _ref6.from,
          size = _ref6.size,
          search = _ref6.search,
          sortField = _ref6.sortField,
          sortDirection = _ref6.sortDirection;
      return {
        from: from,
        size: size,
        search: search,
        sortField: sortField,
        sortDirection: sortDirection
      };
    }
  }]);
  return ManagedIndices;
}(_react.Component);

exports.default = ManagedIndices;
module.exports = exports.default;