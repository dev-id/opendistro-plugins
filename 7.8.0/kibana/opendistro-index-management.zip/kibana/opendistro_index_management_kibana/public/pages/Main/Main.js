"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _react = _interopRequireWildcard(require("react"));

var _reactRouterDom = require("react-router-dom");

var _eui = require("@elastic/eui");

var _Policies = _interopRequireDefault(require("../Policies"));

var _ManagedIndices = _interopRequireDefault(require("../ManagedIndices"));

var _Indices = _interopRequireDefault(require("../Indices"));

var _CreatePolicy = _interopRequireDefault(require("../CreatePolicy"));

var _ChangePolicy = _interopRequireDefault(require("../ChangePolicy"));

var _Modal = require("../../components/Modal");

var _services = require("../../services");

var _constants = require("../../utils/constants");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Navigation;

(function (Navigation) {
  Navigation["IndexManagement"] = "Index Management";
  Navigation["IndexPolicies"] = "Index Policies";
  Navigation["ManagedIndices"] = "Managed Indices";
  Navigation["Indices"] = "Indices";
})(Navigation || (Navigation = {}));

var Pathname;

(function (Pathname) {
  Pathname["IndexPolicies"] = "/index-policies";
  Pathname["ManagedIndices"] = "/managed-indices";
  Pathname["Indices"] = "/indices";
})(Pathname || (Pathname = {}));

var Main = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(Main, _Component);

  var _super = _createSuper(Main);

  function Main() {
    (0, _classCallCheck2.default)(this, Main);
    return _super.apply(this, arguments);
  }

  (0, _createClass2.default)(Main, [{
    key: "render",
    value: function render() {
      var pathname = this.props.location.pathname;
      var sideNav = [{
        name: Navigation.IndexManagement,
        id: 0,
        href: "#".concat(Pathname.IndexPolicies),
        items: [{
          name: Navigation.IndexPolicies,
          id: 1,
          href: "#".concat(Pathname.IndexPolicies),
          isSelected: pathname === Pathname.IndexPolicies
        }, {
          name: Navigation.ManagedIndices,
          id: 2,
          href: "#".concat(Pathname.ManagedIndices),
          isSelected: pathname === Pathname.ManagedIndices
        }, {
          name: Navigation.Indices,
          id: 3,
          href: "#".concat(Pathname.Indices),
          isSelected: pathname === Pathname.Indices
        }]
      }];
      return /*#__PURE__*/_react.default.createElement(_services.ServicesConsumer, null, function (services) {
        return services && /*#__PURE__*/_react.default.createElement(_Modal.ModalProvider, null, /*#__PURE__*/_react.default.createElement(_Modal.ModalRoot, {
          services: services
        }), /*#__PURE__*/_react.default.createElement(_eui.EuiPage, null, /*#__PURE__*/_react.default.createElement(_eui.EuiPageSideBar, {
          style: {
            minWidth: 150
          }
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiSideNav, {
          style: {
            width: 150
          },
          items: sideNav
        })), /*#__PURE__*/_react.default.createElement(_eui.EuiPageBody, null, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Switch, null, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.CHANGE_POLICY,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement(_ChangePolicy.default, (0, _extends2.default)({}, props, {
              managedIndexService: services.managedIndexService,
              indexService: services.indexService
            }));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.CREATE_POLICY,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement(_CreatePolicy.default, (0, _extends2.default)({}, props, {
              isEdit: false,
              policyService: services.policyService
            }));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.EDIT_POLICY,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement(_CreatePolicy.default, (0, _extends2.default)({}, props, {
              isEdit: true,
              policyService: services.policyService
            }));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.INDEX_POLICIES,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement("div", {
              style: {
                padding: "25px 25px"
              }
            }, /*#__PURE__*/_react.default.createElement(_Policies.default, (0, _extends2.default)({}, props, {
              policyService: services.policyService
            })));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.MANAGED_INDICES,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement(_ManagedIndices.default, (0, _extends2.default)({}, props, {
              managedIndexService: services.managedIndexService
            })));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
          path: _constants.ROUTES.INDICES,
          render: function render(props) {
            return /*#__PURE__*/_react.default.createElement("div", {
              style: {
                padding: "25px 25px"
              }
            }, /*#__PURE__*/_react.default.createElement(_Indices.default, (0, _extends2.default)({}, props, {
              indexService: services.indexService
            })));
          }
        }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Redirect, {
          from: "/",
          to: _constants.ROUTES.INDEX_POLICIES
        })))));
      });
    }
  }]);
  return Main;
}(_react.Component);

exports.default = Main;
module.exports = exports.default;