"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _chrome = _interopRequireDefault(require("ui/chrome"));

var _notify = require("ui/notify");

var _queryString = _interopRequireDefault(require("query-string"));

var _constants = require("../../utils/constants");

var _DefinePolicy = _interopRequireDefault(require("../../components/DefinePolicy"));

var _ConfigurePolicy = _interopRequireDefault(require("../../components/ConfigurePolicy"));

var _constants2 = require("../../../../utils/constants");

var _helpers = require("../../../../utils/helpers");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var CreatePolicy = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(CreatePolicy, _Component);

  var _super = _createSuper(CreatePolicy);

  function CreatePolicy(props) {
    var _this;

    (0, _classCallCheck2.default)(this, CreatePolicy);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "componentDidMount", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _queryString$parse, id;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _chrome.default.breadcrumbs.set([_constants2.BREADCRUMBS.INDEX_MANAGEMENT, _constants2.BREADCRUMBS.INDEX_POLICIES]);

              if (!_this.props.isEdit) {
                _context.next = 14;
                break;
              }

              _queryString$parse = _queryString.default.parse(_this.props.location.search), id = _queryString$parse.id;

              if (!(typeof id === "string" && !!id)) {
                _context.next = 10;
                break;
              }

              _chrome.default.breadcrumbs.push(_constants2.BREADCRUMBS.EDIT_POLICY);

              _chrome.default.breadcrumbs.push({
                text: id
              });

              _context.next = 8;
              return _this.getPolicyToEdit(id);

            case 8:
              _context.next = 12;
              break;

            case 10:
              _notify.toastNotifications.addDanger("Invalid policy id: ".concat(id));

              _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);

            case 12:
              _context.next = 16;
              break;

            case 14:
              _chrome.default.breadcrumbs.push(_constants2.BREADCRUMBS.CREATE_POLICY);

              _this.setState({
                jsonString: _constants.DEFAULT_POLICY
              });

            case 16:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getPolicyToEdit", /*#__PURE__*/function () {
      var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(policyId) {
        var policyService, response;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                policyService = _this.props.policyService;
                _context2.next = 4;
                return policyService.getPolicy(policyId);

              case 4:
                response = _context2.sent;

                if (response.ok) {
                  _this.setState({
                    policySeqNo: response.response.seqNo,
                    policyPrimaryTerm: response.response.primaryTerm,
                    policyId: response.response.id,
                    jsonString: JSON.stringify({
                      policy: response.response.policy
                    }, null, 4)
                  });
                } else {
                  _notify.toastNotifications.addDanger("Could not load the policy: ".concat(response.error));

                  _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);
                }

                _context2.next = 12;
                break;

              case 8:
                _context2.prev = 8;
                _context2.t0 = _context2["catch"](0);

                _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context2.t0, "Could not load the policy"));

                _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);

              case 12:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 8]]);
      }));

      return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onCreate", /*#__PURE__*/function () {
      var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(policyId, policy) {
        var policyService, response;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                policyService = _this.props.policyService;
                _context3.prev = 1;
                _context3.next = 4;
                return policyService.putPolicy(policy, policyId);

              case 4:
                response = _context3.sent;

                if (response.ok) {
                  _notify.toastNotifications.addSuccess("Created policy: ".concat(response.response._id));

                  _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);
                } else {
                  _this.setState({
                    submitError: response.error
                  });
                }

                _context3.next = 11;
                break;

              case 8:
                _context3.prev = 8;
                _context3.t0 = _context3["catch"](1);

                _this.setState({
                  submitError: (0, _helpers.getErrorMessage)(_context3.t0, "There was a problem creating the policy")
                });

              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[1, 8]]);
      }));

      return function (_x2, _x3) {
        return _ref3.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onUpdate", /*#__PURE__*/function () {
      var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(policyId, policy) {
        var policyService, _this$state, policyPrimaryTerm, policySeqNo, response;

        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                policyService = _this.props.policyService;
                _this$state = _this.state, policyPrimaryTerm = _this$state.policyPrimaryTerm, policySeqNo = _this$state.policySeqNo;

                if (!(policySeqNo == null || policyPrimaryTerm == null)) {
                  _context4.next = 6;
                  break;
                }

                _notify.toastNotifications.addDanger("Could not update policy without seqNo and primaryTerm");

                return _context4.abrupt("return");

              case 6:
                _context4.next = 8;
                return policyService.putPolicy(policy, policyId, policySeqNo, policyPrimaryTerm);

              case 8:
                response = _context4.sent;

                if (response.ok) {
                  _notify.toastNotifications.addSuccess("Updated policy: ".concat(response.response._id));

                  _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);
                } else {
                  _this.setState({
                    submitError: response.error
                  });
                }

                _context4.next = 15;
                break;

              case 12:
                _context4.prev = 12;
                _context4.t0 = _context4["catch"](0);

                _this.setState({
                  submitError: (0, _helpers.getErrorMessage)(_context4.t0, "There was a problem updating the policy")
                });

              case 15:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[0, 12]]);
      }));

      return function (_x4, _x5) {
        return _ref4.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onCancel", function () {
      if (_this.props.isEdit) _this.props.history.goBack();else _this.props.history.push(_constants2.ROUTES.INDEX_POLICIES);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChange", function (e) {
      var hasSubmitted = _this.state.hasSubmitted;
      var policyId = e.target.value;
      if (hasSubmitted) _this.setState({
        policyId: policyId,
        policyIdError: policyId ? "" : "Required"
      });else _this.setState({
        policyId: policyId
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeJSON", function (value) {
      _this.setState({
        jsonString: value
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onAutoIndent", function () {
      try {
        var parsedJSON = JSON.parse(_this.state.jsonString);

        _this.setState({
          jsonString: JSON.stringify(parsedJSON, null, 4)
        });
      } catch (err) {// do nothing
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSubmit", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
      var isEdit, _this$state2, policyId, jsonString, policy;

      return _regenerator.default.wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              isEdit = _this.props.isEdit;
              _this$state2 = _this.state, policyId = _this$state2.policyId, jsonString = _this$state2.jsonString;

              _this.setState({
                submitError: "",
                isSubmitting: true,
                hasSubmitted: true
              });

              _context5.prev = 3;

              if (policyId) {
                _context5.next = 8;
                break;
              }

              _this.setState({
                policyIdError: "Required"
              });

              _context5.next = 16;
              break;

            case 8:
              policy = JSON.parse(jsonString);

              if (!isEdit) {
                _context5.next = 14;
                break;
              }

              _context5.next = 12;
              return _this.onUpdate(policyId, policy);

            case 12:
              _context5.next = 16;
              break;

            case 14:
              _context5.next = 16;
              return _this.onCreate(policyId, policy);

            case 16:
              _context5.next = 22;
              break;

            case 18:
              _context5.prev = 18;
              _context5.t0 = _context5["catch"](3);

              _notify.toastNotifications.addDanger("Invalid Policy JSON");

              console.error(_context5.t0);

            case 22:
              _this.setState({
                isSubmitting: false
              });

            case 23:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5, null, [[3, 18]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "renderEditCallOut", function () {
      var isEdit = _this.props.isEdit;
      if (!isEdit) return null;
      return /*#__PURE__*/_react.default.createElement(_react.Fragment, null, /*#__PURE__*/_react.default.createElement(_eui.EuiCallOut, {
        title: "Edits to the policy are not automatically applied to indices that are already being managed by this policy.",
        iconType: "questionInCircle"
      }, /*#__PURE__*/_react.default.createElement("p", null, "This ensures that any update to a policy doesn't harm indices that are running under an older version of the policy. To carry over your edits to these indices, please use the \"Change Policy\" under \"Managed Indices\" to reapply the policy after submitting your edits.", " ", /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
        href: _constants2.DOCUMENTATION_URL,
        target: "_blank"
      }, "Learn more ", /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
        type: "popout",
        size: "s"
      })))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null));
    });
    _this.state = {
      policySeqNo: null,
      policyPrimaryTerm: null,
      policyId: "",
      policyIdError: "",
      submitError: "",
      jsonString: "",
      isSubmitting: false,
      hasSubmitted: false
    };
    return _this;
  }

  (0, _createClass2.default)(CreatePolicy, [{
    key: "render",
    value: function render() {
      var isEdit = this.props.isEdit;
      var _this$state3 = this.state,
          policyId = _this$state3.policyId,
          policyIdError = _this$state3.policyIdError,
          jsonString = _this$state3.jsonString,
          submitError = _this$state3.submitError,
          isSubmitting = _this$state3.isSubmitting;
      var hasJSONError = false;

      try {
        JSON.parse(jsonString);
      } catch (err) {
        hasJSONError = true;
      }

      return /*#__PURE__*/_react.default.createElement("div", {
        style: {
          padding: "25px 50px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiTitle, {
        size: "l"
      }, /*#__PURE__*/_react.default.createElement("h1", null, isEdit ? "Edit" : "Create", " policy")), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), this.renderEditCallOut(), /*#__PURE__*/_react.default.createElement(_ConfigurePolicy.default, {
        policyId: policyId,
        policyIdError: policyIdError,
        isEdit: isEdit,
        onChange: this.onChange
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_DefinePolicy.default, {
        jsonString: jsonString,
        onChange: this.onChangeJSON,
        onAutoIndent: this.onAutoIndent,
        hasJSONError: hasJSONError
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), submitError && /*#__PURE__*/_react.default.createElement(_eui.EuiCallOut, {
        title: "Sorry, there was an error",
        color: "danger",
        iconType: "alert"
      }, /*#__PURE__*/_react.default.createElement("p", null, submitError)), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        alignItems: "center",
        justifyContent: "flexEnd"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButtonEmpty, {
        onClick: this.onCancel,
        "data-test-subj": "createPolicyCancelButton"
      }, "Cancel")), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        fill: true,
        onClick: this.onSubmit,
        isLoading: isSubmitting,
        "data-test-subj": "createPolicyCreateButton"
      }, isEdit ? "Update" : "Create"))));
    }
  }]);
  return CreatePolicy;
}(_react.Component);

exports.default = CreatePolicy;
module.exports = exports.default;