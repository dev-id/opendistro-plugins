"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

var _ContentPanel = require("../../../../components/ContentPanel");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var ConfigurePolicy = function ConfigurePolicy(_ref) {
  var isEdit = _ref.isEdit,
      policyId = _ref.policyId,
      policyIdError = _ref.policyIdError,
      onChange = _ref.onChange;
  return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
    bodyStyles: {
      padding: "initial"
    },
    title: "Name policy",
    titleSize: "s"
  }, /*#__PURE__*/_react.default.createElement("div", {
    style: {
      paddingLeft: "10px"
    }
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
    size: "xs"
  }, /*#__PURE__*/_react.default.createElement("p", null, "Policies let you automatically perform administrative operations on indices.")), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
    label: "Policy ID",
    helpText: "Specify a unique ID that is easy to recognize and remember.",
    isInvalid: !!policyIdError,
    error: policyIdError
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiFieldText, {
    isInvalid: !!policyIdError,
    placeholder: "hot_cold_workflow",
    readOnly: isEdit,
    value: policyId,
    onChange: onChange
  }))));
}; // @ts-ignore


var _default = ConfigurePolicy;
exports.default = _default;
module.exports = exports.default;