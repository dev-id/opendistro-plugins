"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

var _ContentPanel = require("../../../../components/ContentPanel");

require("brace/theme/github");

require("brace/mode/json");

var _DarkMode = require("../../../../components/DarkMode");

var _constants = require("../../../../utils/constants");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
// TODO: Add custom autocomplete for Policy syntax
var DefinePolicy = function DefinePolicy(_ref) {
  var jsonString = _ref.jsonString,
      onChange = _ref.onChange,
      onAutoIndent = _ref.onAutoIndent,
      hasJSONError = _ref.hasJSONError;
  return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
    bodyStyles: {
      padding: "initial"
    },
    title: "Define policy",
    titleSize: "s",
    actions: [/*#__PURE__*/_react.default.createElement(_eui.EuiCopy, {
      textToCopy: jsonString
    }, function (copy) {
      return /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        iconType: "copyClipboard",
        onClick: copy
      }, "Copy");
    }), /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
      iconType: "editorAlignLeft",
      onClick: onAutoIndent,
      disabled: hasJSONError
    }, "Auto indent")]
  }, /*#__PURE__*/_react.default.createElement("div", {
    style: {
      paddingLeft: "10px"
    }
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
    size: "xs"
  }, /*#__PURE__*/_react.default.createElement("p", null, "You can think of policies as state machines. \"Actions\" are the operations ISM performs when an index is in a certain state. \"Transitions\" define when to move from one state to another.", " ", /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
    href: _constants.DOCUMENTATION_URL,
    target: "_blank"
  }, "Learn more ", /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
    type: "popout",
    size: "s"
  }))))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/_react.default.createElement(_DarkMode.DarkModeConsumer, null, function (isDarkMode) {
    return /*#__PURE__*/_react.default.createElement(_eui.EuiCodeEditor, {
      mode: "json",
      theme: isDarkMode ? "sense-dark" : "github",
      width: "100%",
      value: jsonString,
      onChange: onChange,
      setOptions: {
        fontSize: "14px"
      },
      "aria-label": "Code Editor"
    });
  }));
};

var _default = DefinePolicy;
exports.default = _default;
module.exports = exports.default;