"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Radio = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _chrome = _interopRequireDefault(require("ui/chrome"));

var _ChangeManagedIndices = _interopRequireDefault(require("../../components/ChangeManagedIndices"));

var _NewPolicy = _interopRequireDefault(require("../../components/NewPolicy"));

var _constants = require("../../../../utils/constants");

var _notify = require("ui/notify");

var _helpers = require("../../../../utils/helpers");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Radio;
exports.Radio = Radio;

(function (Radio) {
  Radio["Current"] = "current";
  Radio["State"] = "state";
})(Radio || (exports.Radio = Radio = {}));

var ChangePolicy = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(ChangePolicy, _Component);

  var _super = _createSuper(ChangePolicy);

  function ChangePolicy() {
    var _this;

    (0, _classCallCheck2.default)(this, ChangePolicy);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      selectedPolicies: [],
      selectedManagedIndices: [],
      selectedStateFilters: [],
      stateRadioIdSelected: Radio.Current,
      stateSelected: "",
      managedIndicesError: "",
      selectedPoliciesError: "",
      hasSubmitted: false
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeSelectedPolicy", function (selectedPolicies) {
      // reset the selected state and radio whenever we select a new policy
      var selectedPoliciesError = selectedPolicies.length ? "" : "Required";

      _this.setState({
        selectedPolicies: selectedPolicies,
        selectedPoliciesError: selectedPoliciesError,
        stateSelected: "",
        stateRadioIdSelected: Radio.Current
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeManagedIndices", function (selectedManagedIndices) {
      var managedIndicesError = selectedManagedIndices.length ? "" : "Required";

      if (!selectedManagedIndices.length) {
        _this.onChangeStateFilters([]);
      }

      _this.setState({
        selectedManagedIndices: selectedManagedIndices,
        managedIndicesError: managedIndicesError
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeStateFilters", function (selectedStateFilters) {
      _this.setState({
        selectedStateFilters: selectedStateFilters
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeStateRadio", function (optionId) {
      _this.setState({
        stateRadioIdSelected: optionId
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onStateSelectChange", function (e) {
      _this.setState({
        stateSelected: e.target.value
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangePolicy", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var managedIndexService, _this$state, selectedPolicies, selectedManagedIndices, selectedStateFilters, stateRadioIdSelected, stateSelected, indices, policyId, state, include, changePolicyResponse, _changePolicyResponse, updatedIndices, failedIndices, failures;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              managedIndexService = _this.props.managedIndexService;
              _this$state = _this.state, selectedPolicies = _this$state.selectedPolicies, selectedManagedIndices = _this$state.selectedManagedIndices, selectedStateFilters = _this$state.selectedStateFilters, stateRadioIdSelected = _this$state.stateRadioIdSelected, stateSelected = _this$state.stateSelected;

              if (!(!selectedManagedIndices.length || !selectedPolicies.length)) {
                _context.next = 5;
                break;
              }

              return _context.abrupt("return");

            case 5:
              indices = selectedManagedIndices.map(function (selectedManagedIndex) {
                return selectedManagedIndex.label;
              });
              policyId = selectedPolicies[0].label;
              state = stateRadioIdSelected === Radio.State ? stateSelected : null;
              include = selectedStateFilters.map(function (selectedStateFilter) {
                return {
                  state: selectedStateFilter.label
                };
              });
              _context.next = 11;
              return managedIndexService.changePolicy(indices, policyId, state, include);

            case 11:
              changePolicyResponse = _context.sent;

              if (changePolicyResponse.ok) {
                _changePolicyResponse = changePolicyResponse.response, updatedIndices = _changePolicyResponse.updatedIndices, failedIndices = _changePolicyResponse.failedIndices, failures = _changePolicyResponse.failures;

                if (updatedIndices) {
                  _notify.toastNotifications.addSuccess("Changed policy on ".concat(updatedIndices, " indices"));
                }

                if (failures) {
                  _notify.toastNotifications.addDanger("Failed to change policy on ".concat(failedIndices.map(function (failedIndex) {
                    return "[".concat(failedIndex.indexName, ", ").concat(failedIndex.reason, "]");
                  }).join(", ")));
                }
              } else {
                _notify.toastNotifications.addDanger(changePolicyResponse.error);
              }

              _context.next = 18;
              break;

            case 15:
              _context.prev = 15;
              _context.t0 = _context["catch"](0);

              _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context.t0, "There was a problem changing policy"));

            case 18:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 15]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSubmit", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
      var _this$state2, selectedPolicies, selectedManagedIndices, managedIndicesError, selectedPoliciesError;

      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _this$state2 = _this.state, selectedPolicies = _this$state2.selectedPolicies, selectedManagedIndices = _this$state2.selectedManagedIndices;
              managedIndicesError = selectedManagedIndices.length ? "" : "Required";
              selectedPoliciesError = selectedPolicies.length ? "" : "Required";

              _this.setState({
                managedIndicesError: managedIndicesError,
                selectedPoliciesError: selectedPoliciesError,
                hasSubmitted: true
              });

              if (!(selectedManagedIndices.length && selectedPolicies.length)) {
                _context2.next = 7;
                break;
              }

              _context2.next = 7;
              return _this.onChangePolicy();

            case 7:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    })));
    return _this;
  }

  (0, _createClass2.default)(ChangePolicy, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _chrome.default.breadcrumbs.set([_constants.BREADCRUMBS.INDEX_MANAGEMENT, _constants.BREADCRUMBS.MANAGED_INDICES, _constants.BREADCRUMBS.CHANGE_POLICY]);

              case 1:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          indexService = _this$props.indexService,
          managedIndexService = _this$props.managedIndexService;
      var _this$state3 = this.state,
          selectedPolicies = _this$state3.selectedPolicies,
          selectedManagedIndices = _this$state3.selectedManagedIndices,
          selectedStateFilters = _this$state3.selectedStateFilters,
          stateRadioIdSelected = _this$state3.stateRadioIdSelected,
          stateSelected = _this$state3.stateSelected,
          managedIndicesError = _this$state3.managedIndicesError,
          selectedPoliciesError = _this$state3.selectedPoliciesError,
          hasSubmitted = _this$state3.hasSubmitted;
      return /*#__PURE__*/_react.default.createElement("div", {
        style: {
          padding: "0px 25px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiTitle, {
        size: "l"
      }, /*#__PURE__*/_react.default.createElement("h1", null, "Change policy")), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_ChangeManagedIndices.default, {
        managedIndexService: managedIndexService,
        selectedManagedIndices: selectedManagedIndices,
        selectedStateFilters: selectedStateFilters,
        onChangeManagedIndices: this.onChangeManagedIndices,
        onChangeStateFilters: this.onChangeStateFilters,
        managedIndicesError: hasSubmitted ? managedIndicesError : ""
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_NewPolicy.default, {
        indexService: indexService,
        selectedPolicies: selectedPolicies,
        stateRadioIdSelected: stateRadioIdSelected,
        stateSelected: stateSelected,
        onChangePolicy: this.onChangeSelectedPolicy,
        onChangeStateRadio: this.onChangeStateRadio,
        onStateSelectChange: this.onStateSelectChange,
        selectedPoliciesError: hasSubmitted ? selectedPoliciesError : ""
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, null), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        alignItems: "center",
        justifyContent: "flexEnd"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        fill: true,
        onClick: this.onSubmit,
        "data-test-subj": "changePolicyChangeButton"
      }, "Change"))));
    }
  }]);
  return ChangePolicy;
}(_react.Component);

exports.default = ChangePolicy;