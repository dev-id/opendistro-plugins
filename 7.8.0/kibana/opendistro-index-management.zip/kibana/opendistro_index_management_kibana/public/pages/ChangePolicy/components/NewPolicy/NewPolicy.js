"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireDefault(require("react"));

var _lodash = _interopRequireDefault(require("lodash"));

var _eui = require("@elastic/eui");

var _notify = require("ui/notify");

var _ContentPanel = require("../../../../components/ContentPanel");

var _ChangePolicy = require("../../containers/ChangePolicy/ChangePolicy");

var _helpers = require("../../../../utils/helpers");

var _constants = require("../../../../utils/constants");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var NewPolicy = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(NewPolicy, _React$Component);

  var _super = _createSuper(NewPolicy);

  function NewPolicy() {
    var _this;

    (0, _classCallCheck2.default)(this, NewPolicy);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      stateOptions: [],
      policiesIsLoading: false,
      policies: []
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onPolicySearchChange", /*#__PURE__*/function () {
      var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(searchValue) {
        var indexService, searchPoliciesResponse, policies;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                indexService = _this.props.indexService;

                _this.setState({
                  policiesIsLoading: true,
                  policies: []
                });

                _context.prev = 2;
                _context.next = 5;
                return indexService.searchPolicies(searchValue, true);

              case 5:
                searchPoliciesResponse = _context.sent;

                if (searchPoliciesResponse.ok) {
                  policies = searchPoliciesResponse.response.hits.hits.map(function (hit) {
                    return {
                      label: hit._id,
                      value: hit._source.policy
                    };
                  });

                  _this.setState({
                    policies: policies
                  });
                } else {
                  if (searchPoliciesResponse.error.startsWith("[index_not_found_exception]")) {
                    _notify.toastNotifications.addDanger("You have not created a policy yet");
                  } else {
                    _notify.toastNotifications.addDanger(searchPoliciesResponse.error);
                  }
                }

                _context.next = 12;
                break;

              case 9:
                _context.prev = 9;
                _context.t0 = _context["catch"](2);

                _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context.t0, "There was a problem searching policies"));

              case 12:
                _this.setState({
                  policiesIsLoading: false
                });

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[2, 9]]);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    return _this;
  }

  (0, _createClass2.default)(NewPolicy, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.onPolicySearchChange("");

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          selectedPolicies = _this$props.selectedPolicies,
          stateRadioIdSelected = _this$props.stateRadioIdSelected,
          stateSelected = _this$props.stateSelected,
          selectedPoliciesError = _this$props.selectedPoliciesError;
      var _this$state = this.state,
          policies = _this$state.policies,
          policiesIsLoading = _this$state.policiesIsLoading;
      var hasSelectedPolicy = !!selectedPolicies.length;

      var stateOptions = _lodash.default.flatten(selectedPolicies.map(function (selectedPolicy) {
        return selectedPolicy.value.states.map(function (state) {
          return {
            value: state.name,
            text: state.name
          };
        });
      }));

      var currentRadio = {
        id: _ChangePolicy.Radio.Current,
        label: "Keep indices in their current state after the policy takes effect"
      };
      var stateRadio = {
        id: _ChangePolicy.Radio.State,
        label: "Switch indices to the following state after the policy takes effect",
        disabled: !hasSelectedPolicy || !stateOptions.length
      };
      var radioOptions = [currentRadio, stateRadio];
      return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
        bodyStyles: {
          padding: "initial"
        },
        title: "Choose new policy",
        titleSize: "s"
      }, /*#__PURE__*/_react.default.createElement("div", {
        style: {
          paddingLeft: "10px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
        size: "xs"
      }, /*#__PURE__*/_react.default.createElement("p", null, "When the new policy will take effect depends on the current state of indices and the states of the new policy.", " ", /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
        href: _constants.DOCUMENTATION_URL,
        target: "_blank"
      }, "Learn more ", /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
        type: "popout",
        size: "s"
      })))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "s"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "New policy",
        isInvalid: !!selectedPoliciesError,
        error: selectedPoliciesError
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiComboBox, {
        placeholder: "",
        async: true,
        options: policies,
        isInvalid: !!selectedPoliciesError,
        singleSelection: {
          asPlainText: true
        },
        selectedOptions: selectedPolicies,
        isLoading: policiesIsLoading // @ts-ignore
        ,
        onChange: this.props.onChangePolicy,
        onSearchChange: this.onPolicySearchChange
      })), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "m"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiRadioGroup, {
        options: radioOptions,
        idSelected: stateRadioIdSelected,
        onChange: this.props.onChangeStateRadio
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "s"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, null, /*#__PURE__*/_react.default.createElement(_eui.EuiSelect, {
        disabled: stateRadioIdSelected !== _ChangePolicy.Radio.State,
        options: stateOptions,
        value: stateSelected,
        onChange: this.props.onStateSelectChange,
        "aria-label": "Start state for new policy"
      }))));
    }
  }]);
  return NewPolicy;
}(_react.default.Component);

exports.default = NewPolicy;
module.exports = exports.default;