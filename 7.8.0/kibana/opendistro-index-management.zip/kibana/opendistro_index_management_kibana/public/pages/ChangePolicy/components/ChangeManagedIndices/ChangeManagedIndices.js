"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _notify = require("ui/notify");

var _ContentPanel = require("../../../../components/ContentPanel");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var ChangeManagedIndices = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(ChangeManagedIndices, _Component);

  var _super = _createSuper(ChangeManagedIndices);

  function ChangeManagedIndices() {
    var _this;

    (0, _classCallCheck2.default)(this, ChangeManagedIndices);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      managedIndicesIsLoading: false,
      managedIndices: [],
      stateFilterSearchValue: ""
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onManagedIndexSearchChange", /*#__PURE__*/function () {
      var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(searchValue) {
        var managedIndexService, queryParamsString, managedIndicesResponse, options, managedIndices;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                managedIndexService = _this.props.managedIndexService;

                _this.setState({
                  managedIndicesIsLoading: true,
                  managedIndices: []
                });

                _context.prev = 2;
                // only bring back the first 10 results descending by name
                queryParamsString = "from=0&size=10&search=".concat(searchValue, "&sortDirection=desc&sortField=name");
                _context.next = 6;
                return managedIndexService.getManagedIndices(queryParamsString);

              case 6:
                managedIndicesResponse = _context.sent;

                if (managedIndicesResponse.ok) {
                  options = searchValue.trim() ? [{
                    label: "".concat(searchValue, "*")
                  }] : [];
                  managedIndices = managedIndicesResponse.response.managedIndices.map(function (managedIndex) {
                    return {
                      label: managedIndex.index,
                      value: managedIndex
                    };
                  });

                  _this.setState({
                    managedIndices: options.concat(managedIndices)
                  });
                } else {
                  if (managedIndicesResponse.error.startsWith("[index_not_found_exception]")) {
                    _notify.toastNotifications.addDanger("You have not created a managed index yet");
                  } else {
                    _notify.toastNotifications.addDanger(managedIndicesResponse.error);
                  }
                }

                _context.next = 13;
                break;

              case 10:
                _context.prev = 10;
                _context.t0 = _context["catch"](2);

                _notify.toastNotifications.addDanger(_context.t0.message);

              case 13:
                _this.setState({
                  managedIndicesIsLoading: false
                });

              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[2, 10]]);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onStateFilterSearchChange", function (searchValue) {
      _this.setState({
        stateFilterSearchValue: searchValue
      });
    });
    return _this;
  }

  (0, _createClass2.default)(ChangeManagedIndices, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.onManagedIndexSearchChange("");

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          managedIndices = _this$state.managedIndices,
          managedIndicesIsLoading = _this$state.managedIndicesIsLoading,
          stateFilterSearchValue = _this$state.stateFilterSearchValue;
      var _this$props = this.props,
          selectedManagedIndices = _this$props.selectedManagedIndices,
          selectedStateFilters = _this$props.selectedStateFilters,
          managedIndicesError = _this$props.managedIndicesError;
      var uniqueStates = selectedManagedIndices.reduce(function (accu, selectedManagedIndex) {
        if (!selectedManagedIndex.value) return accu;
        var policy = selectedManagedIndex.value.policy;
        if (!policy) return accu;
        policy.states.forEach(function (state) {
          accu.add(state.name);
        });
        return accu;
      }, new Set());
      var options = stateFilterSearchValue.trim() ? [{
        label: "".concat(stateFilterSearchValue, "*")
      }] : [];
      var stateOptions = options.concat((0, _toConsumableArray2.default)(uniqueStates).map(function (stateName) {
        return {
          label: stateName
        };
      }));
      return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
        bodyStyles: {
          padding: "initial"
        },
        title: "Choose managed indices",
        titleSize: "s"
      }, /*#__PURE__*/_react.default.createElement("div", {
        style: {
          paddingLeft: "10px"
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "m"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "Managed indices",
        helpText: "You can use * as wildcards to form index patterns.",
        isInvalid: !!managedIndicesError,
        error: managedIndicesError
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiComboBox, {
        placeholder: "",
        async: true,
        options: managedIndices,
        isInvalid: !!managedIndicesError,
        selectedOptions: selectedManagedIndices,
        isLoading: managedIndicesIsLoading // @ts-ignore
        ,
        onChange: this.props.onChangeManagedIndices,
        onSearchChange: this.onManagedIndexSearchChange
      })), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "State filters",
        helpText: "Apply new policy only on managed indices in these states."
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiComboBox, {
        isDisabled: !selectedManagedIndices.length,
        placeholder: "Choose state filters",
        options: stateOptions,
        selectedOptions: selectedStateFilters // @ts-ignore
        ,
        onChange: this.props.onChangeStateFilters,
        onSearchChange: this.onStateFilterSearchChange
      }))));
    }
  }]);
  return ChangeManagedIndices;
}(_react.Component);

exports.default = ChangeManagedIndices;
module.exports = exports.default;