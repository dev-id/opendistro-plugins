"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _chrome = _interopRequireDefault(require("ui/chrome"));

var _notify = require("ui/notify");

var _lodash = _interopRequireDefault(require("lodash"));

var _queryString = _interopRequireDefault(require("query-string"));

var _eui = require("@elastic/eui");

var _ContentPanel = require("../../../../components/ContentPanel");

var _IndexControls = _interopRequireDefault(require("../../components/IndexControls"));

var _ApplyPolicyModal = _interopRequireDefault(require("../../components/ApplyPolicyModal"));

var _IndexEmptyPrompt = _interopRequireDefault(require("../../components/IndexEmptyPrompt"));

var _constants = require("../../utils/constants");

var _Modal = require("../../../../components/Modal");

var _helpers = require("../../utils/helpers");

var _constants2 = require("../../../../utils/constants");

var _helpers2 = require("../../../../utils/helpers");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Indices = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(Indices, _Component);

  var _super = _createSuper(Indices);

  function Indices(props) {
    var _this;

    (0, _classCallCheck2.default)(this, Indices);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getIndices", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var _this$props, indexService, history, queryParamsString, getIndicesResponse, _getIndicesResponse$r, indices, totalIndices;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this.setState({
                loadingIndices: true
              });

              _context.prev = 1;
              _this$props = _this.props, indexService = _this$props.indexService, history = _this$props.history;
              queryParamsString = _queryString.default.stringify(Indices.getQueryObjectFromState(_this.state));
              history.replace(_objectSpread({}, _this.props.location, {
                search: queryParamsString
              }));
              _context.next = 7;
              return indexService.getIndices(queryParamsString);

            case 7:
              getIndicesResponse = _context.sent;

              if (getIndicesResponse.ok) {
                _getIndicesResponse$r = getIndicesResponse.response, indices = _getIndicesResponse$r.indices, totalIndices = _getIndicesResponse$r.totalIndices;

                _this.setState({
                  indices: indices,
                  totalIndices: totalIndices
                });
              } else {
                _notify.toastNotifications.addDanger(getIndicesResponse.error);
              }

              _context.next = 14;
              break;

            case 11:
              _context.prev = 11;
              _context.t0 = _context["catch"](1);

              _notify.toastNotifications.addDanger((0, _helpers2.getErrorMessage)(_context.t0, "There was a problem loading the indices"));

            case 14:
              _this.setState({
                loadingIndices: false
              });

            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[1, 11]]);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onTableChange", function (_ref2) {
      var tablePage = _ref2.page,
          sort = _ref2.sort;
      var page = tablePage.index,
          size = tablePage.size;
      var sortField = sort.field,
          sortDirection = sort.direction;

      _this.setState({
        from: page * size,
        size: size,
        sortField: sortField,
        sortDirection: sortDirection
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSelectionChange", function (selectedItems) {
      _this.setState({
        selectedItems: selectedItems
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSearchChange", function (e) {
      _this.setState({
        from: 0,
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onPageClick", function (page) {
      var size = _this.state.size;

      _this.setState({
        from: page * size
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "resetFilters", function () {
      _this.setState({
        search: _constants.DEFAULT_QUERY_PARAMS.search
      });
    });

    var _getURLQueryParams = (0, _helpers.getURLQueryParams)(_this.props.location),
        from = _getURLQueryParams.from,
        _size = _getURLQueryParams.size,
        search = _getURLQueryParams.search,
        _sortField = _getURLQueryParams.sortField,
        _sortDirection = _getURLQueryParams.sortDirection;

    _this.state = {
      totalIndices: 0,
      from: from,
      size: _size,
      search: search,
      sortField: _sortField,
      sortDirection: _sortDirection,
      selectedItems: [],
      indices: [],
      loadingIndices: true
    };
    _this.getIndices = _lodash.default.debounce(_this.getIndices, 500, {
      leading: true
    });
    return _this;
  }

  (0, _createClass2.default)(Indices, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _chrome.default.breadcrumbs.set([_constants2.BREADCRUMBS.INDEX_MANAGEMENT, _constants2.BREADCRUMBS.INDICES]);

                _context2.next = 3;
                return this.getIndices();

              case 3:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(prevProps, prevState) {
        var prevQuery, currQuery;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                prevQuery = Indices.getQueryObjectFromState(prevState);
                currQuery = Indices.getQueryObjectFromState(this.state);

                if (_lodash.default.isEqual(prevQuery, currQuery)) {
                  _context3.next = 5;
                  break;
                }

                _context3.next = 5;
                return this.getIndices();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function componentDidUpdate(_x, _x2) {
        return _componentDidUpdate.apply(this, arguments);
      }

      return componentDidUpdate;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          totalIndices = _this$state.totalIndices,
          from = _this$state.from,
          size = _this$state.size,
          search = _this$state.search,
          sortField = _this$state.sortField,
          sortDirection = _this$state.sortDirection,
          selectedItems = _this$state.selectedItems,
          indices = _this$state.indices,
          loadingIndices = _this$state.loadingIndices;
      var filterIsApplied = !!search;
      var page = Math.floor(from / size);
      var pagination = {
        pageIndex: page,
        pageSize: size,
        pageSizeOptions: _constants.DEFAULT_PAGE_SIZE_OPTIONS,
        totalItemCount: totalIndices
      };
      var sorting = {
        sort: {
          direction: sortDirection,
          field: sortField
        }
      };
      var selection = {
        onSelectionChange: this.onSelectionChange
      };
      return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanel, {
        actions: /*#__PURE__*/_react.default.createElement(_Modal.ModalConsumer, null, function (_ref3) {
          var onShow = _ref3.onShow;
          return /*#__PURE__*/_react.default.createElement(_ContentPanel.ContentPanelActions, {
            actions: [{
              text: "Apply policy",
              buttonProps: {
                disabled: !selectedItems.length,
                onClick: function onClick() {
                  return onShow(_ApplyPolicyModal.default, {
                    indices: selectedItems.map(function (item) {
                      return item.index;
                    })
                  });
                }
              }
            }]
          });
        }),
        bodyStyles: {
          padding: "initial"
        },
        title: "Indices"
      }, /*#__PURE__*/_react.default.createElement(_IndexControls.default, {
        activePage: page,
        pageCount: Math.ceil(totalIndices / size) || 1,
        search: search,
        onSearchChange: this.onSearchChange,
        onPageClick: this.onPageClick,
        onRefresh: this.getIndices
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
        margin: "xs"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiBasicTable, {
        columns: _constants.indicesColumns,
        isSelectable: true,
        itemId: "index",
        items: indices,
        noItemsMessage: /*#__PURE__*/_react.default.createElement(_IndexEmptyPrompt.default, {
          filterIsApplied: filterIsApplied,
          loading: loadingIndices,
          resetFilters: this.resetFilters
        }),
        onChange: this.onTableChange,
        pagination: pagination,
        selection: selection,
        sorting: sorting
      }));
    }
  }], [{
    key: "getQueryObjectFromState",
    value: function getQueryObjectFromState(_ref4) {
      var from = _ref4.from,
          size = _ref4.size,
          search = _ref4.search,
          sortField = _ref4.sortField,
          sortDirection = _ref4.sortDirection;
      return {
        from: from,
        size: size,
        search: search,
        sortField: sortField,
        sortDirection: sortDirection
      };
    }
  }]);
  return Indices;
}(_react.Component);

exports.default = Indices;
module.exports = exports.default;