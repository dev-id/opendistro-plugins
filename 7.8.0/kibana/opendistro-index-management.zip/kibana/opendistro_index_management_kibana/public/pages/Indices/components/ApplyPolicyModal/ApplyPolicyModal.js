"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _notify = require("ui/notify");

var _lodash = _interopRequireDefault(require("lodash"));

var _eui = require("@elastic/eui");

var _helpers = require("../../../../utils/helpers");

var _constants = require("../../../../utils/constants");

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var ApplyPolicyModal = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(ApplyPolicyModal, _Component);

  var _super = _createSuper(ApplyPolicyModal);

  function ApplyPolicyModal() {
    var _this;

    (0, _classCallCheck2.default)(this, ApplyPolicyModal);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "state", {
      isLoading: false,
      selectedPolicy: null,
      selectedPolicyError: "",
      hasRolloverAction: false,
      policyOptions: [],
      rolloverAlias: "",
      rolloverAliasError: "",
      hasSubmitted: false
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onApplyPolicy", /*#__PURE__*/function () {
      var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(selectedPolicy, hasRolloverAction, rolloverAlias) {
        var _this$props, onClose, indices, indexService, policyId, applyPolicyResponse, _applyPolicyResponse$, updatedIndices, failedIndices, failures;

        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _this$props = _this.props, onClose = _this$props.onClose, indices = _this$props.indices, indexService = _this$props.services.indexService;
                policyId = selectedPolicy.label;
                _context.next = 5;
                return indexService.applyPolicy(indices, policyId);

              case 5:
                applyPolicyResponse = _context.sent;

                if (!applyPolicyResponse.ok) {
                  _context.next = 17;
                  break;
                }

                _applyPolicyResponse$ = applyPolicyResponse.response, updatedIndices = _applyPolicyResponse$.updatedIndices, failedIndices = _applyPolicyResponse$.failedIndices, failures = _applyPolicyResponse$.failures;

                if (!updatedIndices) {
                  _context.next = 13;
                  break;
                }

                _notify.toastNotifications.addSuccess("Applied policy to ".concat(updatedIndices, " indices"));

                if (!(hasRolloverAction && rolloverAlias && indices.length === 1)) {
                  _context.next = 13;
                  break;
                }

                _context.next = 13;
                return _this.onEditRolloverAlias(indices[0], rolloverAlias);

              case 13:
                if (failures) {
                  _notify.toastNotifications.addDanger("Failed to apply policy to ".concat(failedIndices.map(function (failedIndex) {
                    return "[".concat(failedIndex.indexName, ", ").concat(failedIndex.reason, "]");
                  }).join(", ")));
                }

                onClose();
                _context.next = 18;
                break;

              case 17:
                _notify.toastNotifications.addDanger(applyPolicyResponse.error);

              case 18:
                _context.next = 23;
                break;

              case 20:
                _context.prev = 20;
                _context.t0 = _context["catch"](0);

                _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context.t0, "There was a problem adding policy to indices"));

              case 23:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 20]]);
      }));

      return function (_x, _x2, _x3) {
        return _ref.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onEditRolloverAlias", /*#__PURE__*/function () {
      var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(index, rolloverAlias) {
        var indexService, response;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                indexService = _this.props.services.indexService;
                _context2.prev = 1;
                _context2.next = 4;
                return indexService.editRolloverAlias(index, rolloverAlias);

              case 4:
                response = _context2.sent;

                if (response.ok) {
                  if (response.response.acknowledged) {
                    _notify.toastNotifications.addSuccess("Edited rollover alias on ".concat(index));
                  } else {
                    _notify.toastNotifications.addDanger("Failed to edit rollover alias on ".concat(index));
                  }
                } else {
                  _notify.toastNotifications.addDanger(response.error);
                }

                _context2.next = 11;
                break;

              case 8:
                _context2.prev = 8;
                _context2.t0 = _context2["catch"](1);

                _notify.toastNotifications.addDanger((0, _helpers.getErrorMessage)(_context2.t0, "There was a problem editing rollover alias on ".concat(index)));

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[1, 8]]);
      }));

      return function (_x4, _x5) {
        return _ref2.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onPolicySearchChange", /*#__PURE__*/function () {
      var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(searchValue) {
        var indexService, searchPoliciesResponse, policies;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                indexService = _this.props.services.indexService;

                _this.setState({
                  isLoading: true,
                  policyOptions: []
                });

                _context3.prev = 2;
                _context3.next = 5;
                return indexService.searchPolicies(searchValue, true);

              case 5:
                searchPoliciesResponse = _context3.sent;

                if (searchPoliciesResponse.ok) {
                  policies = searchPoliciesResponse.response.hits.hits.map(function (hit) {
                    return {
                      label: hit._id,
                      policy: hit._source.policy
                    };
                  });

                  _this.setState({
                    policyOptions: policies
                  });
                } else {
                  if (searchPoliciesResponse.error.startsWith("[index_not_found_exception]")) {
                    _notify.toastNotifications.addDanger("You have not created a policy yet");
                  } else {
                    _notify.toastNotifications.addDanger(searchPoliciesResponse.error);
                  }
                }

                _context3.next = 12;
                break;

              case 9:
                _context3.prev = 9;
                _context3.t0 = _context3["catch"](2);

                _notify.toastNotifications.addDanger(_context3.t0.message);

              case 12:
                _this.setState({
                  isLoading: false
                });

              case 13:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[2, 9]]);
      }));

      return function (_x6) {
        return _ref3.apply(this, arguments);
      };
    }());
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeSelectedPolicy", function (selectedPolicies) {
      var selectedPolicy = selectedPolicies.length ? selectedPolicies[0] : null;

      var hasRolloverAction = _this.hasRolloverAction(selectedPolicy);

      _this.setState({
        selectedPolicy: selectedPolicy,
        hasRolloverAction: hasRolloverAction,
        selectedPolicyError: _this.getSelectedPolicyError(selectedPolicy)
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeRolloverAlias", function (e) {
      var rolloverAlias = e.target.value;

      _this.setState({
        rolloverAlias: rolloverAlias,
        rolloverAliasError: _this.getRolloverAliasError(rolloverAlias)
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSubmit", /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
      var _this$state, selectedPolicy, rolloverAlias, selectedPolicyError, rolloverAliasError, hasSubmitError;

      return _regenerator.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _this$state = _this.state, selectedPolicy = _this$state.selectedPolicy, rolloverAlias = _this$state.rolloverAlias;
              selectedPolicyError = _this.getSelectedPolicyError(selectedPolicy);
              rolloverAliasError = _this.getRolloverAliasError(rolloverAlias);
              hasSubmitError = !!selectedPolicyError || !!rolloverAliasError;

              if (!hasSubmitError) {
                _context4.next = 8;
                break;
              }

              _this.setState({
                selectedPolicyError: selectedPolicyError,
                rolloverAliasError: rolloverAliasError,
                hasSubmitted: true
              });

              _context4.next = 10;
              break;

            case 8:
              _context4.next = 10;
              return _this.onApplyPolicy(selectedPolicy, _this.hasRolloverAction(selectedPolicy), rolloverAlias);

            case 10:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    })));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getRolloverAliasError", function (rolloverAlias) {
      var hasRolloverAction = _this.state.hasRolloverAction;
      var indices = _this.props.indices;
      var hasSingleIndexSelected = indices.length === 1;
      var requiresAlias = hasRolloverAction && hasSingleIndexSelected;
      var hasAliasError = requiresAlias && !rolloverAlias;
      return hasAliasError ? "Required" : "";
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getSelectedPolicyError", function (selectedPolicy) {
      return selectedPolicy ? "" : "You must select a policy";
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "hasRolloverAction", function (selectedPolicy) {
      return _lodash.default.get(selectedPolicy, "policy.states", []).some(function (state) {
        return state.actions.some(function (action) {
          return action.hasOwnProperty("rollover");
        });
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "renderRollover", function () {
      var _this$state2 = _this.state,
          rolloverAlias = _this$state2.rolloverAlias,
          hasRolloverAction = _this$state2.hasRolloverAction,
          rolloverAliasError = _this$state2.rolloverAliasError,
          hasSubmitted = _this$state2.hasSubmitted;
      var indices = _this.props.indices;
      var hasSingleIndexSelected = indices.length === 1;
      if (!hasRolloverAction) return null;

      if (hasSingleIndexSelected) {
        return /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
          label: "Rollover alias",
          helpText: /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
            size: "xs",
            grow: false
          }, /*#__PURE__*/_react.default.createElement("p", null, "This policy includes a rollover action. Specify a rollover alias.", " ", /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
            href: _constants.DOCUMENTATION_URL,
            target: "_blank"
          }, "Learn more ", /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
            type: "popout",
            size: "s"
          })))),
          isInvalid: hasSubmitted && !!rolloverAliasError,
          error: rolloverAliasError,
          fullWidth: true
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiFieldText, {
          isInvalid: hasSubmitted && !!rolloverAliasError,
          placeholder: "Rollover alias",
          value: rolloverAlias,
          onChange: _this.onChangeRolloverAlias,
          fullWidth: true
        }));
      }

      return /*#__PURE__*/_react.default.createElement(_eui.EuiCallOut, {
        style: {
          width: "350px"
        },
        title: /*#__PURE__*/_react.default.createElement("p", null, "You are applying a policy with rollover to multiple indices. You will need to add a unique rollover_alias setting to each index."),
        iconType: "alert",
        size: "s",
        color: "warning"
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "renderPreview", function () {
      var selectedPolicy = _this.state.selectedPolicy;
      if (!selectedPolicy) return null;
      var policyString = '';

      try {
        policyString = JSON.stringify({
          policy: selectedPolicy.policy
        }, null, 4);
      } catch (err) {
        console.error(err);
      }

      if (!policyString) {
        return null;
      }

      return /*#__PURE__*/_react.default.createElement(_react.Fragment, null, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
        size: "xs",
        grow: false
      }, /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("strong", null, "Preview"))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "s"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiCodeBlock, {
        language: "json",
        fontSize: "m",
        style: {
          height: "200px"
        }
      }, policyString), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "m"
      }));
    });
    return _this;
  }

  (0, _createClass2.default)(ApplyPolicyModal, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.onPolicySearchChange("");

              case 2:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this$state3 = this.state,
          policyOptions = _this$state3.policyOptions,
          selectedPolicy = _this$state3.selectedPolicy,
          selectedPolicyError = _this$state3.selectedPolicyError,
          isLoading = _this$state3.isLoading,
          hasSubmitted = _this$state3.hasSubmitted;
      var onClose = this.props.onClose;
      var selectedOptions = selectedPolicy ? [selectedPolicy] : [];
      return /*#__PURE__*/_react.default.createElement(_eui.EuiOverlayMask, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModal, {
        onCancel: onClose,
        onClose: onClose
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeader, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeaderTitle, null, "Apply policy")), /*#__PURE__*/_react.default.createElement(_eui.EuiModalBody, null, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
        size: "xs",
        grow: false
      }, /*#__PURE__*/_react.default.createElement("p", null, "Choose the policy you want to use for the selected indices. A copy of the policy will be created and applied to the indices.")), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "m"
      }), /*#__PURE__*/_react.default.createElement(_eui.EuiFormRow, {
        label: "Policy ID",
        isInvalid: hasSubmitted && !!selectedPolicyError,
        error: selectedPolicyError,
        fullWidth: true
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiComboBox, {
        placeholder: "Search policies",
        async: true,
        options: policyOptions,
        singleSelection: {
          asPlainText: true
        },
        selectedOptions: selectedOptions,
        isLoading: isLoading,
        isInvalid: hasSubmitted && !!selectedPolicyError,
        onChange: this.onChangeSelectedPolicy,
        onSearchChange: this.onPolicySearchChange,
        fullWidth: true
      })), this.renderPreview(), this.renderRollover()), /*#__PURE__*/_react.default.createElement(_eui.EuiModalFooter, null, /*#__PURE__*/_react.default.createElement(_eui.EuiButtonEmpty, {
        onClick: onClose,
        "data-test-subj": "applyPolicyModalCloseButton"
      }, "Cancel"), /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        onClick: this.onSubmit,
        fill: true,
        "data-test-subj": "applyPolicyModalEditButton"
      }, "Apply"))));
    }
  }]);
  return ApplyPolicyModal;
}(_react.Component);

exports.default = ApplyPolicyModal;
module.exports = exports.default;