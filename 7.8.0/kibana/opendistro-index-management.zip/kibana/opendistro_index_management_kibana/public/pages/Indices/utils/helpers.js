"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getURLQueryParams = getURLQueryParams;

var _queryString = _interopRequireDefault(require("query-string"));

var _constants = require("./constants");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
function getURLQueryParams(location) {
  var _queryString$parse = _queryString.default.parse(location.search),
      from = _queryString$parse.from,
      size = _queryString$parse.size,
      search = _queryString$parse.search,
      sortField = _queryString$parse.sortField,
      sortDirection = _queryString$parse.sortDirection;

  return {
    // @ts-ignore
    from: isNaN(parseInt(from, 10)) ? _constants.DEFAULT_QUERY_PARAMS.from : parseInt(from, 10),
    // @ts-ignore
    size: isNaN(parseInt(size, 10)) ? _constants.DEFAULT_QUERY_PARAMS.size : parseInt(size, 10),
    search: typeof search !== "string" ? _constants.DEFAULT_QUERY_PARAMS.search : search,
    sortField: typeof sortField !== "string" ? "index" : sortField,
    sortDirection: typeof sortDirection !== "string" ? _constants.DEFAULT_QUERY_PARAMS.sortDirection : sortDirection
  };
}