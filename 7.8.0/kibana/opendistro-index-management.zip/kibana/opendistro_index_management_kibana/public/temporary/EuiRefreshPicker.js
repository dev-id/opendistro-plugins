"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _AsyncInterval = _interopRequireDefault(require("./AsyncInterval"));

function _createSuper(Derived) { return function () { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

// Some of this code is from EUI library, but cannot be used until we are at 7.2+
// This is a temporary import for 7.0 and 7.1
var EuiRefreshPicker = /*#__PURE__*/function (_Component) {
  (0, _inherits2.default)(EuiRefreshPicker, _Component);

  var _super = _createSuper(EuiRefreshPicker);

  function EuiRefreshPicker() {
    var _this;

    (0, _classCallCheck2.default)(this, EuiRefreshPicker);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "asyncInterval", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "componentDidMount", function () {
      if (!_this.props.isPaused) {
        _this.startInterval(_this.props.refreshInterval);
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "componentWillUnmount", function () {
      _this.stopInterval();
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onRefreshChange", function (_ref) {
      var refreshInterval = _ref.refreshInterval,
          isPaused = _ref.isPaused;

      _this.stopInterval();

      if (!isPaused) {
        _this.startInterval(refreshInterval);
      }

      if (_this.props.onRefreshChange) {
        _this.props.onRefreshChange({
          refreshInterval: refreshInterval,
          isPaused: isPaused
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "stopInterval", function () {
      if (_this.asyncInterval) {
        _this.asyncInterval.stop();
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "startInterval", function (refreshInterval) {
      var onRefresh = _this.props.onRefresh;

      if (onRefresh) {
        var handler = function handler() {
          onRefresh({
            refreshInterval: refreshInterval
          });
        };

        _this.asyncInterval = new _AsyncInterval.default(handler, refreshInterval);
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onTimeChange", function () {});
    return _this;
  }

  (0, _createClass2.default)(EuiRefreshPicker, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/_react.default.createElement(_eui.EuiSuperDatePicker, {
        isAutoRefreshOnly: true,
        isPaused: this.props.isPaused,
        refreshInterval: this.props.refreshInterval,
        onRefreshChange: this.onRefreshChange,
        onTimeChange: this.onTimeChange
      });
    }
  }]);
  return EuiRefreshPicker;
}(_react.Component);

exports.default = EuiRefreshPicker;
module.exports = exports.default;