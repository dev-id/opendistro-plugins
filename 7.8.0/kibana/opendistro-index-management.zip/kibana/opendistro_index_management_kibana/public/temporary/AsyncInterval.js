"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

// Code from https://github.com/elastic/eui
// Used under the Apache-2.0 license.
// This is from EUI library, but cannot be used until we are at 7.2+
// This is a temporary import for 7.0 and 7.1
var AsyncInterval = function AsyncInterval(_fn, refreshInterval) {
  var _this = this;

  (0, _classCallCheck2.default)(this, AsyncInterval);
  (0, _defineProperty2.default)(this, "timeoutId", void 0);
  (0, _defineProperty2.default)(this, "isStopped", false);
  (0, _defineProperty2.default)(this, "__pendingFn", void 0);
  (0, _defineProperty2.default)(this, "setAsyncInterval", function (fn, ms) {
    if (!_this.isStopped) {
      _this.timeoutId = window.setTimeout( /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(document.visibilityState === "visible")) {
                  _context.next = 4;
                  break;
                }

                _context.next = 3;
                return fn();

              case 3:
                _this.__pendingFn = _context.sent;

              case 4:
                _this.setAsyncInterval(fn, ms);

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      })), ms);
    }
  });
  (0, _defineProperty2.default)(this, "stop", function () {
    _this.isStopped = true;
    window.clearTimeout(_this.timeoutId);
  });
  this.setAsyncInterval(_fn, refreshInterval);
};

exports.default = AsyncInterval;
module.exports = exports.default;