"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SortDirection = exports.BREADCRUMBS = exports.ROUTES = exports.DOCUMENTATION_URL = exports.DEFAULT_EMPTY_DATA = exports.PLUGIN_NAME = void 0;

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var PLUGIN_NAME = "opendistro_index_management_kibana";
exports.PLUGIN_NAME = PLUGIN_NAME;
var DEFAULT_EMPTY_DATA = "-";
exports.DEFAULT_EMPTY_DATA = DEFAULT_EMPTY_DATA;
var DOCUMENTATION_URL = "https://opendistro.github.io/for-elasticsearch-docs/docs/ism/";
exports.DOCUMENTATION_URL = DOCUMENTATION_URL;
var ROUTES = Object.freeze({
  CHANGE_POLICY: "/change-policy",
  CREATE_POLICY: "/create-policy",
  EDIT_POLICY: "/edit-policy",
  MANAGED_INDICES: "/managed-indices",
  INDEX_POLICIES: "/index-policies",
  INDICES: "/indices"
});
exports.ROUTES = ROUTES;
var BREADCRUMBS = Object.freeze({
  INDEX_MANAGEMENT: {
    text: "Index Management",
    href: "#/"
  },
  INDICES: {
    text: "Indices",
    href: "#".concat(ROUTES.INDICES)
  },
  INDEX_POLICIES: {
    text: "Index policies",
    href: "#".concat(ROUTES.INDEX_POLICIES)
  },
  MANAGED_INDICES: {
    text: "Managed Indices",
    href: "#".concat(ROUTES.MANAGED_INDICES)
  },
  EDIT_POLICY: {
    text: "Edit policy"
  },
  CREATE_POLICY: {
    text: "Create policy"
  },
  CHANGE_POLICY: {
    text: "Change policy"
  }
}); // TODO: Kibana EUI has a SortDirection already

exports.BREADCRUMBS = BREADCRUMBS;
var SortDirection;
exports.SortDirection = SortDirection;

(function (SortDirection) {
  SortDirection["ASC"] = "asc";
  SortDirection["DESC"] = "desc";
})(SortDirection || (exports.SortDirection = SortDirection = {}));