"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _constants = require("../../server/utils/constants");

var _constants2 = require("../../utils/constants");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var IndexService = function IndexService(httpClient) {
  var _this = this;

  (0, _classCallCheck2.default)(this, IndexService);
  (0, _defineProperty2.default)(this, "httpClient", void 0);
  (0, _defineProperty2.default)(this, "getIndices", /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(queryParamsString) {
      var url, response;
      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              url = "..".concat(_constants2.NODE_API._INDICES, "?").concat(queryParamsString);
              _context.next = 3;
              return _this.httpClient.get(url);

            case 3:
              response = _context.sent;
              return _context.abrupt("return", response.data);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "applyPolicy", /*#__PURE__*/function () {
    var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(indices, policyId) {
      var body, url, response;
      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              body = {
                indices: indices,
                policyId: policyId
              };
              url = "..".concat(_constants2.NODE_API.APPLY_POLICY);
              _context2.next = 4;
              return _this.httpClient.post(url, body);

            case 4:
              response = _context2.sent;
              return _context2.abrupt("return", response.data);

            case 6:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function (_x2, _x3) {
      return _ref2.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "editRolloverAlias", /*#__PURE__*/function () {
    var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(index, alias) {
      var body, url, response;
      return _regenerator.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              body = {
                index: index,
                alias: alias
              };
              url = "..".concat(_constants2.NODE_API.EDIT_ROLLOVER_ALIAS);
              _context3.next = 4;
              return _this.httpClient.post(url, body);

            case 4:
              response = _context3.sent;
              return _context3.abrupt("return", response.data);

            case 6:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function (_x4, _x5) {
      return _ref3.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "searchPolicies", /*#__PURE__*/function () {
    var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(searchValue) {
      var source,
          mustQuery,
          body,
          url,
          response,
          _args4 = arguments;
      return _regenerator.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              source = _args4.length > 1 && _args4[1] !== undefined ? _args4[1] : false;
              mustQuery = {
                query_string: {
                  default_field: "policy.policy_id",
                  default_operator: "AND",
                  query: "*".concat(searchValue.trim().split(" ").join("* *"), "*")
                }
              };
              body = {
                index: _constants.INDEX.OPENDISTRO_ISM_CONFIG,
                size: 10,
                query: {
                  _source: source,
                  query: {
                    bool: {
                      must: [mustQuery, {
                        exists: {
                          field: "policy"
                        }
                      }]
                    }
                  }
                }
              };
              url = "..".concat(_constants2.NODE_API._SEARCH);
              _context4.next = 6;
              return _this.httpClient.post(url, body);

            case 6:
              response = _context4.sent;
              return _context4.abrupt("return", response.data);

            case 8:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function (_x6) {
      return _ref4.apply(this, arguments);
    };
  }());
  this.httpClient = httpClient;
};

exports.default = IndexService;
module.exports = exports.default;