"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _queryString = _interopRequireDefault(require("query-string"));

var _constants = require("../../utils/constants");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var PolicyService = function PolicyService(httpClient) {
  var _this = this;

  (0, _classCallCheck2.default)(this, PolicyService);
  (0, _defineProperty2.default)(this, "httpClient", void 0);
  (0, _defineProperty2.default)(this, "getPolicies", /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(queryParamsString) {
      var url, response;
      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              url = "..".concat(_constants.NODE_API.POLICIES, "?").concat(queryParamsString);
              _context.next = 3;
              return _this.httpClient.get(url);

            case 3:
              response = _context.sent;
              return _context.abrupt("return", response.data);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "putPolicy", /*#__PURE__*/function () {
    var _ref2 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(policy, policyId, seqNo, primaryTerm) {
      var queryParamsString, url, response;
      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              queryParamsString = _queryString.default.stringify({
                seqNo: seqNo,
                primaryTerm: primaryTerm
              });
              url = "..".concat(_constants.NODE_API.POLICIES, "/").concat(policyId, "?").concat(queryParamsString);
              _context2.next = 4;
              return _this.httpClient.put(url, policy);

            case 4:
              response = _context2.sent;
              return _context2.abrupt("return", response.data);

            case 6:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function (_x2, _x3, _x4, _x5) {
      return _ref2.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "getPolicy", /*#__PURE__*/function () {
    var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(policyId) {
      var url, response;
      return _regenerator.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              url = "..".concat(_constants.NODE_API.POLICIES, "/").concat(policyId);
              _context3.next = 3;
              return _this.httpClient.get(url);

            case 3:
              response = _context3.sent;
              return _context3.abrupt("return", response.data);

            case 5:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function (_x6) {
      return _ref3.apply(this, arguments);
    };
  }());
  (0, _defineProperty2.default)(this, "deletePolicy", /*#__PURE__*/function () {
    var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee4(policyId) {
      var url, response;
      return _regenerator.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              url = "..".concat(_constants.NODE_API.POLICIES, "/").concat(policyId);
              _context4.next = 3;
              return _this.httpClient.delete(url);

            case 3:
              response = _context4.sent;
              return _context4.abrupt("return", response.data);

            case 5:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function (_x7) {
      return _ref4.apply(this, arguments);
    };
  }());
  this.httpClient = httpClient;
};

exports.default = PolicyService;
module.exports = exports.default;