"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "DarkModeConsumer", {
  enumerable: true,
  get: function get() {
    return _DarkMode.DarkModeConsumer;
  }
});
Object.defineProperty(exports, "DarkModeContext", {
  enumerable: true,
  get: function get() {
    return _DarkMode.DarkModeContext;
  }
});

var _DarkMode = require("./DarkMode");