"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "ModalConsumer", {
  enumerable: true,
  get: function get() {
    return _Modal.ModalConsumer;
  }
});
Object.defineProperty(exports, "ModalProvider", {
  enumerable: true,
  get: function get() {
    return _Modal.ModalProvider;
  }
});
Object.defineProperty(exports, "ModalRoot", {
  enumerable: true,
  get: function get() {
    return _ModalRoot.default;
  }
});

var _Modal = require("./Modal");

var _ModalRoot = _interopRequireDefault(require("./ModalRoot"));