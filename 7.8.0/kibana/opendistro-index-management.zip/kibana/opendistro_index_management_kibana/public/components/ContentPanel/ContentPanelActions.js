"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

var _Modal = require("../Modal");

/*
 * Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
var ContentPanelActions = function ContentPanelActions(_ref) {
  var actions = _ref.actions;
  return /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
    justifyContent: "spaceBetween",
    alignItems: "center"
  }, actions.map(function (_ref2, index) {
    var text = _ref2.text,
        _ref2$buttonProps = _ref2.buttonProps,
        buttonProps = _ref2$buttonProps === void 0 ? {} : _ref2$buttonProps,
        _ref2$flexItemProps = _ref2.flexItemProps,
        flexItemProps = _ref2$flexItemProps === void 0 ? {} : _ref2$flexItemProps,
        _ref2$modal = _ref2.modal,
        modal = _ref2$modal === void 0 ? null : _ref2$modal;

    var button = /*#__PURE__*/_react.default.createElement(_eui.EuiButton, (0, _extends2.default)({}, buttonProps, {
      "data-test-subj": "".concat(text, "Button")
    }), text);

    if (modal) {
      button = /*#__PURE__*/_react.default.createElement(_Modal.ModalConsumer, null, function (_ref3) {
        var onShow = _ref3.onShow;
        return /*#__PURE__*/_react.default.createElement(_eui.EuiButton, (0, _extends2.default)({}, buttonProps, {
          onClick: modal.onClickModal(onShow),
          "data-test-subj": "".concat(text, "Button")
        }), text);
      });
    }

    return /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, (0, _extends2.default)({}, flexItemProps, {
      grow: false,
      key: index
    }), button);
  }));
};

var _default = ContentPanelActions;
exports.default = _default;
module.exports = exports.default;