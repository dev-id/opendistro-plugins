"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

var ContentPanel = function ContentPanel(_ref) {
  var _ref$title = _ref.title,
      title = _ref$title === void 0 ? "" : _ref$title,
      _ref$titleSize = _ref.titleSize,
      titleSize = _ref$titleSize === void 0 ? "l" : _ref$titleSize,
      _ref$bodyStyles = _ref.bodyStyles,
      bodyStyles = _ref$bodyStyles === void 0 ? {} : _ref$bodyStyles,
      _ref$panelStyles = _ref.panelStyles,
      panelStyles = _ref$panelStyles === void 0 ? {} : _ref$panelStyles,
      _ref$horizontalRuleCl = _ref.horizontalRuleClassName,
      horizontalRuleClassName = _ref$horizontalRuleCl === void 0 ? "" : _ref$horizontalRuleCl,
      actions = _ref.actions,
      children = _ref.children;
  return /*#__PURE__*/_react.default.createElement(_eui.EuiPanel, {
    style: _objectSpread({
      paddingLeft: "0px",
      paddingRight: "0px"
    }, panelStyles)
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
    style: {
      padding: "0px 10px"
    },
    justifyContent: "spaceBetween",
    alignItems: "center"
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, /*#__PURE__*/_react.default.createElement(_eui.EuiTitle, {
    size: titleSize
  }, /*#__PURE__*/_react.default.createElement("h3", null, title))), actions ? /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
    justifyContent: "spaceBetween",
    alignItems: "center"
  }, Array.isArray(actions) ? actions.map(function (action, idx) {
    return /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
      key: idx
    }, action);
  }) : /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, actions))) : null), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
    margin: "xs",
    className: horizontalRuleClassName
  }), /*#__PURE__*/_react.default.createElement("div", {
    style: _objectSpread({
      padding: "0px 10px"
    }, bodyStyles)
  }, children));
};

var _default = ContentPanel;
exports.default = _default;
module.exports = exports.default;